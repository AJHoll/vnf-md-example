--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 12.5
-- Dumped by pg_dump version 12.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "vnf-md-db";
--
-- Name: vnf-md-db; Type: DATABASE; Schema: -; Owner: -
--

CREATE DATABASE "vnf-md-db" WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'Russian_Russia.1251@icu' LC_CTYPE = 'Russian_Russia.1251';


\connect -reuse-previous=on "dbname='vnf-md-db'"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: cmn_doc; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA cmn_doc;


--
-- Name: uni_api; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA uni_api;


--
-- Name: uni_component; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA uni_component;


--
-- Name: uni_const; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA uni_const;


--
-- Name: uni_error; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA uni_error;


--
-- Name: uni_generator; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA uni_generator;


--
-- Name: t_boolean; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_boolean AS boolean;


--
-- Name: t_booleanarray; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_booleanarray AS boolean[];


--
-- Name: t_caption; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_caption AS character varying(254);


--
-- Name: t_captionarray; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_captionarray AS character varying(254)[];


--
-- Name: t_clob; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_clob AS text;


--
-- Name: t_code; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_code AS character varying(254);


--
-- Name: t_codearray; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_codearray AS character varying(254)[];


--
-- Name: t_date; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_date AS date;


--
-- Name: t_datearray; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_datearray AS date[];


--
-- Name: t_datetime; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_datetime AS timestamp without time zone;


--
-- Name: t_datetimearray; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_datetimearray AS timestamp without time zone[];


--
-- Name: t_description; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_description AS character varying(4000);


--
-- Name: t_float; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_float AS double precision;


--
-- Name: t_html; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_html AS text;


--
-- Name: t_id; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_id AS numeric(15,0);


--
-- Name: t_idarray; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_idarray AS numeric(15,0)[];


--
-- Name: t_integer; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_integer AS integer;


--
-- Name: t_integerarray; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_integerarray AS integer[];


--
-- Name: t_json; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_json AS jsonb;


--
-- Name: t_longstring; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_longstring AS character varying(4000);


--
-- Name: t_longstringarray; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_longstringarray AS character varying(4000)[];


--
-- Name: t_money; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_money AS numeric(15,4);


--
-- Name: t_moneyarray; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_moneyarray AS numeric(15,4)[];


--
-- Name: t_name; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_name AS character varying(30);


--
-- Name: t_namearray; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_namearray AS character varying(30)[];


--
-- Name: t_shortstring; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_shortstring AS character varying(254);


--
-- Name: t_shortstringarray; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_shortstringarray AS character varying(254)[];


--
-- Name: t_stringarray; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_stringarray AS text[];


--
-- Name: t_xml; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.t_xml AS xml;


--
-- Name: doc__after_edit(public.t_id); Type: FUNCTION; Schema: cmn_doc; Owner: -
--

CREATE FUNCTION cmn_doc.doc__after_edit(idp_self public.t_id) RETURNS void
    LANGUAGE plpgsql
    AS $$
/*<meta object="cmn_doc.doc__after_edit"
        title="Функция after_edit таблицы cmn_doc.doc"
        author="sys"
        created="29.05.2021"
        version="1.0"
        description="">
</meta>*/
declare
  fv_sum_items t_money;
begin
  perform cmn_doc.doc__validate(idp_self);
  /*<comment creator="Порозов А.В." date="29.05.2021">
      После валидации данных - пересчитываем сумму по документ
    </comment>*/
  begin
    select coalesce(sum(doc_item.f_sum), 0)
    into fv_sum_items
    from cmn_doc.doc_item doc_item
    where doc_item.id_doc = idp_self;
  end;
  -- Оформляем сеттер с внутренним вызовом, чтобы избавиться от сайд-эффектов
  perform cmn_doc.doc__set_sum(idp_self, fv_sum_items, true);
end; $$;


--
-- Name: doc__delete_record(public.t_id); Type: FUNCTION; Schema: cmn_doc; Owner: -
--

CREATE FUNCTION cmn_doc.doc__delete_record(idp_self public.t_id) RETURNS void
    LANGUAGE plpgsql
    AS $$
/*<meta object="cmn_doc.doc__delete_record"
        title="Функция delete_record таблицы cmn_doc.doc"
        author="sys"
        created="29.05.2021"
        version="1.0"
        description="">
</meta>*/
begin
 delete from cmn_doc.doc where id = idp_self;
end; $$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: doc; Type: TABLE; Schema: cmn_doc; Owner: -
--

CREATE TABLE cmn_doc.doc (
    id public.t_id NOT NULL,
    s_number public.t_shortstring DEFAULT 'Б/Н'::character varying NOT NULL,
    d_date public.t_date DEFAULT (now())::public.t_date NOT NULL,
    f_sum public.t_money DEFAULT 0 NOT NULL,
    s_description public.t_description
);


--
-- Name: TABLE doc; Type: COMMENT; Schema: cmn_doc; Owner: -
--

COMMENT ON TABLE cmn_doc.doc IS 'Документ';


--
-- Name: COLUMN doc.id; Type: COMMENT; Schema: cmn_doc; Owner: -
--

COMMENT ON COLUMN cmn_doc.doc.id IS 'Код';


--
-- Name: COLUMN doc.s_number; Type: COMMENT; Schema: cmn_doc; Owner: -
--

COMMENT ON COLUMN cmn_doc.doc.s_number IS 'Номер';


--
-- Name: COLUMN doc.d_date; Type: COMMENT; Schema: cmn_doc; Owner: -
--

COMMENT ON COLUMN cmn_doc.doc.d_date IS 'Дата';


--
-- Name: COLUMN doc.f_sum; Type: COMMENT; Schema: cmn_doc; Owner: -
--

COMMENT ON COLUMN cmn_doc.doc.f_sum IS 'Сумма';


--
-- Name: COLUMN doc.s_description; Type: COMMENT; Schema: cmn_doc; Owner: -
--

COMMENT ON COLUMN cmn_doc.doc.s_description IS 'Примечание';


--
-- Name: doc__get_row(public.t_id); Type: FUNCTION; Schema: cmn_doc; Owner: -
--

CREATE FUNCTION cmn_doc.doc__get_row(idp_self public.t_id) RETURNS cmn_doc.doc
    LANGUAGE sql
    AS $$
/*<meta object="cmn_doc.doc__get_row"
        title="Функция get_row таблицы cmn_doc.doc"
        author="sys"
        created="29.05.2021"
        version="1.0"
        description="">
</meta>*/
  select t.* from cmn_doc.doc t where t.id = idp_self;
$$;


--
-- Name: doc__insert_record(); Type: FUNCTION; Schema: cmn_doc; Owner: -
--

CREATE FUNCTION cmn_doc.doc__insert_record() RETURNS public.t_id
    LANGUAGE plpgsql
    AS $$
/*<meta object="cmn_doc.doc__insert_record"
        title="Функция insert_record таблицы cmn_doc.doc"
        author="sys"
        created="29.05.2021"
        version="1.0"
        description="">
</meta>*/
declare
 rv_row cmn_doc.doc%rowtype;
begin
 rv_row.id := uni_api.get_table_id('cmn_doc','doc');

 insert into cmn_doc.doc(id)
 values(rv_row.id);

 return rv_row.id;

end; $$;


--
-- Name: doc__lock_record(public.t_id); Type: FUNCTION; Schema: cmn_doc; Owner: -
--

CREATE FUNCTION cmn_doc.doc__lock_record(idp_self public.t_id) RETURNS void
    LANGUAGE plpgsql
    AS $$
/*<meta object="cmn_doc.doc__lock_record"
        title="Функция lock_record таблицы cmn_doc.doc"
        author="sys"
        created="29.05.2021"
        version="1.0"
        description="">
</meta>*/
declare
 bv_is_ok t_boolean;
 sv_component_name t_name = 'UNI';
 sv_error_name t_name = 'ENoLockedRow';
begin
 select true into bv_is_ok from cmn_doc.doc where id = idp_self for update nowait;
 exception when lock_not_available then
   perform uni_error.generate(sv_component_name, sv_error_name, idp_self::t_shortstring);
end; $$;


--
-- Name: doc__set_date(public.t_id, public.t_date, public.t_boolean); Type: FUNCTION; Schema: cmn_doc; Owner: -
--

CREATE FUNCTION cmn_doc.doc__set_date(idp_self public.t_id, p_value public.t_date, bp_internal_call public.t_boolean DEFAULT false) RETURNS void
    LANGUAGE plpgsql
    AS $$
/*<meta object="cmn_doc.doc__set_date"
        title="Функция setter для колонки "d_date" таблицы cmn_doc.doc"
        author="sys"
        created="29.05.2021"
        version="1.0"
        description="">
</meta>*/
declare
  sv_schema_name t_name = 'cmn_doc';
  sv_table_name t_name = 'doc';
  sv_column_name t_name = 'd_date';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: doc__set_description(public.t_id, public.t_description, public.t_boolean); Type: FUNCTION; Schema: cmn_doc; Owner: -
--

CREATE FUNCTION cmn_doc.doc__set_description(idp_self public.t_id, p_value public.t_description, bp_internal_call public.t_boolean DEFAULT false) RETURNS void
    LANGUAGE plpgsql
    AS $$
/*<meta object="cmn_doc.doc__set_description"
        title="Функция setter для колонки "s_description" таблицы cmn_doc.doc"
        author="sys"
        created="29.05.2021"
        version="1.0"
        description="">
</meta>*/
declare
  sv_schema_name t_name = 'cmn_doc';
  sv_table_name t_name = 'doc';
  sv_column_name t_name = 's_description';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: doc__set_number(public.t_id, public.t_shortstring, public.t_boolean); Type: FUNCTION; Schema: cmn_doc; Owner: -
--

CREATE FUNCTION cmn_doc.doc__set_number(idp_self public.t_id, p_value public.t_shortstring, bp_internal_call public.t_boolean DEFAULT false) RETURNS void
    LANGUAGE plpgsql
    AS $$
/*<meta object="cmn_doc.doc__set_number"
        title="Функция setter для колонки "s_number" таблицы cmn_doc.doc"
        author="sys"
        created="29.05.2021"
        version="1.0"
        description="">
</meta>*/
declare
  sv_schema_name t_name = 'cmn_doc';
  sv_table_name t_name = 'doc';
  sv_column_name t_name = 's_number';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: doc__set_sum(public.t_id, public.t_money, public.t_boolean); Type: FUNCTION; Schema: cmn_doc; Owner: -
--

CREATE FUNCTION cmn_doc.doc__set_sum(idp_self public.t_id, p_value public.t_money, bp_internal_call public.t_boolean DEFAULT false) RETURNS void
    LANGUAGE plpgsql
    AS $$
/*<meta object="cmn_doc.doc__set_sum"
        title="Функция setter для колонки "f_sum" таблицы cmn_doc.doc"
        author="sys"
        created="29.05.2021"
        version="1.0"
        description="">
</meta>*/
declare
  sv_schema_name t_name = 'cmn_doc';
  sv_table_name t_name = 'doc';
  sv_column_name t_name = 'f_sum';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: doc__validate(public.t_id); Type: FUNCTION; Schema: cmn_doc; Owner: -
--

CREATE FUNCTION cmn_doc.doc__validate(idp_self public.t_id) RETURNS void
    LANGUAGE plpgsql
    AS $$
/*<meta object="cmn_doc.doc__validate"
        title="Функция validate таблицы cmn_doc.doc"
        author="sys"
        created="29.05.2021"
        version="1.0"
        description="">
</meta>*/
begin
 null;
end; $$;


--
-- Name: doc_item__after_edit(public.t_id); Type: FUNCTION; Schema: cmn_doc; Owner: -
--

CREATE FUNCTION cmn_doc.doc_item__after_edit(idp_self public.t_id) RETURNS void
    LANGUAGE plpgsql
    AS $$
/*<meta object="cmn_doc.doc_item__after_edit"
        title="Функция after_edit таблицы cmn_doc.doc_item"
        author="sys"
        created="29.05.2021"
        version="1.0"
        description="">
</meta>*/
declare
  rv_row cmn_doc.doc_item%rowtype;
begin
  perform cmn_doc.doc_item__validate(idp_self);
  /*<comment creator="Порозов А.В." date="31.05.2021">
      После валидации по строке - вызовем сайд-эффект по документу.
    </comment>*/
  /*rv_row := cmn_doc.doc_item__get_row(idp_self);
  perform cmn_doc.doc__after_edit(rv_row.id_doc);*/
end; $$;


--
-- Name: doc_item__delete_record(public.t_id); Type: FUNCTION; Schema: cmn_doc; Owner: -
--

CREATE FUNCTION cmn_doc.doc_item__delete_record(idp_self public.t_id) RETURNS void
    LANGUAGE plpgsql
    AS $$
/*<meta object="cmn_doc.doc_item__delete_record"
        title="Функция delete_record таблицы cmn_doc.doc_item"
        author="sys"
        created="29.05.2021"
        version="1.0"
        description="">
</meta>*/
begin
 delete from cmn_doc.doc_item where id = idp_self;
end; $$;


--
-- Name: doc_item; Type: TABLE; Schema: cmn_doc; Owner: -
--

CREATE TABLE cmn_doc.doc_item (
    id public.t_id NOT NULL,
    id_doc public.t_id NOT NULL,
    s_number public.t_shortstring DEFAULT 'Б/Н'::character varying NOT NULL,
    s_caption public.t_caption,
    f_sum public.t_money DEFAULT 0 NOT NULL,
    n_order public.t_integer DEFAULT 0 NOT NULL
);


--
-- Name: TABLE doc_item; Type: COMMENT; Schema: cmn_doc; Owner: -
--

COMMENT ON TABLE cmn_doc.doc_item IS 'Спецификация документа';


--
-- Name: COLUMN doc_item.id; Type: COMMENT; Schema: cmn_doc; Owner: -
--

COMMENT ON COLUMN cmn_doc.doc_item.id IS 'Код';


--
-- Name: COLUMN doc_item.id_doc; Type: COMMENT; Schema: cmn_doc; Owner: -
--

COMMENT ON COLUMN cmn_doc.doc_item.id_doc IS 'Код документа';


--
-- Name: COLUMN doc_item.s_number; Type: COMMENT; Schema: cmn_doc; Owner: -
--

COMMENT ON COLUMN cmn_doc.doc_item.s_number IS 'Номер';


--
-- Name: COLUMN doc_item.s_caption; Type: COMMENT; Schema: cmn_doc; Owner: -
--

COMMENT ON COLUMN cmn_doc.doc_item.s_caption IS 'Наименование';


--
-- Name: COLUMN doc_item.f_sum; Type: COMMENT; Schema: cmn_doc; Owner: -
--

COMMENT ON COLUMN cmn_doc.doc_item.f_sum IS 'Сумма';


--
-- Name: COLUMN doc_item.n_order; Type: COMMENT; Schema: cmn_doc; Owner: -
--

COMMENT ON COLUMN cmn_doc.doc_item.n_order IS 'Номер п.п';


--
-- Name: doc_item__get_row(public.t_id); Type: FUNCTION; Schema: cmn_doc; Owner: -
--

CREATE FUNCTION cmn_doc.doc_item__get_row(idp_self public.t_id) RETURNS cmn_doc.doc_item
    LANGUAGE sql
    AS $$
/*<meta object="cmn_doc.doc_item__get_row"
        title="Функция get_row таблицы cmn_doc.doc_item"
        author="sys"
        created="29.05.2021"
        version="1.0"
        description="">
</meta>*/
  select t.* from cmn_doc.doc_item t where t.id = idp_self;
$$;


--
-- Name: doc_item__insert_record(public.t_id); Type: FUNCTION; Schema: cmn_doc; Owner: -
--

CREATE FUNCTION cmn_doc.doc_item__insert_record(idp_doc public.t_id) RETURNS public.t_id
    LANGUAGE plpgsql
    AS $$
/*<meta object="cmn_doc.doc_item__insert_record"
        title="Функция insert_record таблицы cmn_doc.doc_item"
        author="sys"
        created="29.05.2021"
        version="1.0"
        description="">
</meta>*/
declare
 rv_row cmn_doc.doc_item%rowtype;
begin
 rv_row.id := uni_api.get_table_id('cmn_doc','doc_item');
 rv_row.id_doc := idp_doc;
 
 begin
   select coalesce(max(doc_item.n_order), 0) + 1
   into rv_row.n_order
   from cmn_doc.doc_item doc_item
   where doc_item.id_doc = rv_row.id_doc;
 end;

 insert into cmn_doc.doc_item(id, id_doc, n_order)
 values(rv_row.id, rv_row.id_doc, rv_row.n_order);

 return rv_row.id;

end; $$;


--
-- Name: doc_item__lock_record(public.t_id); Type: FUNCTION; Schema: cmn_doc; Owner: -
--

CREATE FUNCTION cmn_doc.doc_item__lock_record(idp_self public.t_id) RETURNS void
    LANGUAGE plpgsql
    AS $$
/*<meta object="cmn_doc.doc_item__lock_record"
        title="Функция lock_record таблицы cmn_doc.doc_item"
        author="sys"
        created="29.05.2021"
        version="1.0"
        description="">
</meta>*/
declare
 bv_is_ok t_boolean;
 sv_component_name t_name = 'UNI';
 sv_error_name t_name = 'ENoLockedRow';
begin
 select true into bv_is_ok from cmn_doc.doc_item where id = idp_self for update nowait;
 exception when lock_not_available then
   perform uni_error.generate(sv_component_name, sv_error_name, idp_self::t_shortstring);
end; $$;


--
-- Name: doc_item__set_caption(public.t_id, public.t_caption, public.t_boolean); Type: FUNCTION; Schema: cmn_doc; Owner: -
--

CREATE FUNCTION cmn_doc.doc_item__set_caption(idp_self public.t_id, p_value public.t_caption, bp_internal_call public.t_boolean DEFAULT false) RETURNS void
    LANGUAGE plpgsql
    AS $$
/*<meta object="cmn_doc.doc_item__set_caption"
        title="Функция setter для колонки "s_caption" таблицы cmn_doc.doc_item"
        author="sys"
        created="29.05.2021"
        version="1.0"
        description="">
</meta>*/
declare
  sv_schema_name t_name = 'cmn_doc';
  sv_table_name t_name = 'doc_item';
  sv_column_name t_name = 's_caption';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: doc_item__set_doc(public.t_id, public.t_id, public.t_boolean); Type: FUNCTION; Schema: cmn_doc; Owner: -
--

CREATE FUNCTION cmn_doc.doc_item__set_doc(idp_self public.t_id, p_value public.t_id, bp_internal_call public.t_boolean DEFAULT false) RETURNS void
    LANGUAGE plpgsql
    AS $$
/*<meta object="cmn_doc.doc_item__set_doc"
        title="Функция setter для колонки "id_doc" таблицы cmn_doc.doc_item"
        author="sys"
        created="29.05.2021"
        version="1.0"
        description="">
</meta>*/
declare
  sv_schema_name t_name = 'cmn_doc';
  sv_table_name t_name = 'doc_item';
  sv_column_name t_name = 'id_doc';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: doc_item__set_number(public.t_id, public.t_shortstring, public.t_boolean); Type: FUNCTION; Schema: cmn_doc; Owner: -
--

CREATE FUNCTION cmn_doc.doc_item__set_number(idp_self public.t_id, p_value public.t_shortstring, bp_internal_call public.t_boolean DEFAULT false) RETURNS void
    LANGUAGE plpgsql
    AS $$
/*<meta object="cmn_doc.doc_item__set_number"
        title="Функция setter для колонки "s_number" таблицы cmn_doc.doc_item"
        author="sys"
        created="29.05.2021"
        version="1.0"
        description="">
</meta>*/
declare
  sv_schema_name t_name = 'cmn_doc';
  sv_table_name t_name = 'doc_item';
  sv_column_name t_name = 's_number';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: doc_item__set_order(public.t_id, public.t_integer, public.t_boolean); Type: FUNCTION; Schema: cmn_doc; Owner: -
--

CREATE FUNCTION cmn_doc.doc_item__set_order(idp_self public.t_id, p_value public.t_integer, bp_internal_call public.t_boolean DEFAULT false) RETURNS void
    LANGUAGE plpgsql
    AS $$
/*<meta object="cmn_doc.doc_item__set_order"
        title="Функция setter для колонки "n_order" таблицы cmn_doc.doc_item"
        author="sys"
        created="29.05.2021"
        version="1.0"
        description="">
</meta>*/
declare
  sv_schema_name t_name = 'cmn_doc';
  sv_table_name t_name = 'doc_item';
  sv_column_name t_name = 'n_order';
  sv_identity_field t_name = 'id';
begin
  if p_value is not null then
    perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
  end if;
end; $$;


--
-- Name: doc_item__set_sum(public.t_id, public.t_money, public.t_boolean); Type: FUNCTION; Schema: cmn_doc; Owner: -
--

CREATE FUNCTION cmn_doc.doc_item__set_sum(idp_self public.t_id, p_value public.t_money, bp_internal_call public.t_boolean DEFAULT false) RETURNS void
    LANGUAGE plpgsql
    AS $$
/*<meta object="cmn_doc.doc_item__set_sum"
        title="Функция setter для колонки "f_sum" таблицы cmn_doc.doc_item"
        author="sys"
        created="29.05.2021"
        version="1.0"
        description="">
</meta>*/
declare
  sv_schema_name t_name = 'cmn_doc';
  sv_table_name t_name = 'doc_item';
  sv_column_name t_name = 'f_sum';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: doc_item__validate(public.t_id); Type: FUNCTION; Schema: cmn_doc; Owner: -
--

CREATE FUNCTION cmn_doc.doc_item__validate(idp_self public.t_id) RETURNS void
    LANGUAGE plpgsql
    AS $$
/*<meta object="cmn_doc.doc_item__validate"
        title="Функция validate таблицы cmn_doc.doc_item"
        author="sys"
        created="29.05.2021"
        version="1.0"
        description="">
</meta>*/
begin
 null;
end; $$;


--
-- Name: get_table_id(public.t_name, public.t_name); Type: FUNCTION; Schema: uni_api; Owner: -
--

CREATE FUNCTION uni_api.get_table_id(sp_schema public.t_name, sp_table public.t_name) RETURNS bigint
    LANGUAGE sql
    AS $$
  select nextval(format('%I.seq_%I', sp_schema, sp_table));
$$;


--
-- Name: set_table_field_value(public.t_name, public.t_name, public.t_name, public.t_id, public.t_boolean, public.t_name); Type: FUNCTION; Schema: uni_api; Owner: -
--

CREATE FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_boolean, sp_identityfield public.t_name) RETURNS void
    LANGUAGE plpgsql
    AS $_$
declare
  sv_query text := format('update %I.%I set %I = $1 where %I = $2', sp_schema, sp_table, sp_field, sp_identityfield);
begin
  execute sv_query using p_value, idp_self;
exception
  when others then
    perform uni_error.generate('UNI','EError','Ошибка при обновлении таблицы '||sp_schema||'.'||sp_table||'с ключом "'||idp_self||'"'||Chr(10)||sqlerrm);
end;$_$;


--
-- Name: set_table_field_value(public.t_name, public.t_name, public.t_name, public.t_id, public.t_caption, public.t_name); Type: FUNCTION; Schema: uni_api; Owner: -
--

CREATE FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_caption, sp_identityfield public.t_name) RETURNS void
    LANGUAGE plpgsql
    AS $_$
declare
  sv_query text := format('update %I.%I set %I = $1 where %I = $2', sp_schema, sp_table, sp_field, sp_identityfield);
begin
  execute sv_query using p_value, idp_self;
exception
  when others then
    perform uni_error.generate('UNI','EError','Ошибка при обновлении таблицы '||sp_schema||'.'||sp_table||'с ключом "'||idp_self||'"'||Chr(10)||sqlerrm);
end;$_$;


--
-- Name: set_table_field_value(public.t_name, public.t_name, public.t_name, public.t_id, public.t_clob, public.t_name); Type: FUNCTION; Schema: uni_api; Owner: -
--

CREATE FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_clob, sp_identityfield public.t_name) RETURNS void
    LANGUAGE plpgsql
    AS $_$
declare
  sv_query text := format('update %I.%I set %I = $1 where %I = $2', sp_schema, sp_table, sp_field, sp_identityfield);
begin
  execute sv_query using p_value, idp_self;
exception
  when others then
    perform uni_error.generate('UNI','EError','Ошибка при обновлении таблицы '||sp_schema||'.'||sp_table||'с ключом "'||idp_self||'"'||Chr(10)||sqlerrm);
end;$_$;


--
-- Name: set_table_field_value(public.t_name, public.t_name, public.t_name, public.t_id, public.t_code, public.t_name); Type: FUNCTION; Schema: uni_api; Owner: -
--

CREATE FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_code, sp_identityfield public.t_name) RETURNS void
    LANGUAGE plpgsql
    AS $_$
declare
  sv_query text := format('update %I.%I set %I = $1 where %I = $2', sp_schema, sp_table, sp_field, sp_identityfield);
begin
  execute sv_query using p_value, idp_self;
exception
  when others then
    perform uni_error.generate('UNI','EError','Ошибка при обновлении таблицы '||sp_schema||'.'||sp_table||'с ключом "'||idp_self||'"'||Chr(10)||sqlerrm);
end;$_$;


--
-- Name: set_table_field_value(public.t_name, public.t_name, public.t_name, public.t_id, public.t_date, public.t_name); Type: FUNCTION; Schema: uni_api; Owner: -
--

CREATE FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_date, sp_identityfield public.t_name) RETURNS void
    LANGUAGE plpgsql
    AS $_$
declare
  sv_query text := format('update %I.%I set %I = $1 where %I = $2', sp_schema, sp_table, sp_field, sp_identityfield);
begin
  execute sv_query using p_value, idp_self;
exception
  when others then
    perform uni_error.generate('UNI','EError','Ошибка при обновлении таблицы '||sp_schema||'.'||sp_table||'с ключом "'||idp_self||'"'||Chr(10)||sqlerrm);
end;$_$;


--
-- Name: set_table_field_value(public.t_name, public.t_name, public.t_name, public.t_id, public.t_datetime, public.t_name); Type: FUNCTION; Schema: uni_api; Owner: -
--

CREATE FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_datetime, sp_identityfield public.t_name) RETURNS void
    LANGUAGE plpgsql
    AS $_$
declare
  sv_query text := format('update %I.%I set %I = $1 where %I = $2', sp_schema, sp_table, sp_field, sp_identityfield);
begin
  execute sv_query using p_value, idp_self;
exception
  when others then
    perform uni_error.generate('UNI','EError','Ошибка при обновлении таблицы '||sp_schema||'.'||sp_table||'с ключом "'||idp_self||'"'||Chr(10)||sqlerrm);
end;$_$;


--
-- Name: set_table_field_value(public.t_name, public.t_name, public.t_name, public.t_id, public.t_description, public.t_name); Type: FUNCTION; Schema: uni_api; Owner: -
--

CREATE FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_description, sp_identityfield public.t_name) RETURNS void
    LANGUAGE plpgsql
    AS $_$
declare
  sv_query text := format('update %I.%I set %I = $1 where %I = $2', sp_schema, sp_table, sp_field, sp_identityfield);
begin
  execute sv_query using p_value, idp_self;
exception
  when others then
    perform uni_error.generate('UNI','EError','Ошибка при обновлении таблицы '||sp_schema||'.'||sp_table||'с ключом "'||idp_self||'"'||Chr(10)||sqlerrm);
end;$_$;


--
-- Name: set_table_field_value(public.t_name, public.t_name, public.t_name, public.t_id, public.t_float, public.t_name); Type: FUNCTION; Schema: uni_api; Owner: -
--

CREATE FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_float, sp_identityfield public.t_name) RETURNS void
    LANGUAGE plpgsql
    AS $_$
declare
  sv_query text := format('update %I.%I set %I = $1 where %I = $2', sp_schema, sp_table, sp_field, sp_identityfield);
begin
  execute sv_query using p_value, idp_self;
exception
  when others then
    perform uni_error.generate('UNI','EError','Ошибка при обновлении таблицы '||sp_schema||'.'||sp_table||'с ключом "'||idp_self||'"'||Chr(10)||sqlerrm);
end;$_$;


--
-- Name: set_table_field_value(public.t_name, public.t_name, public.t_name, public.t_id, public.t_html, public.t_name); Type: FUNCTION; Schema: uni_api; Owner: -
--

CREATE FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_html, sp_identityfield public.t_name) RETURNS void
    LANGUAGE plpgsql
    AS $_$
declare
  sv_query text := format('update %I.%I set %I = $1 where %I = $2', sp_schema, sp_table, sp_field, sp_identityfield);
begin
  execute sv_query using p_value, idp_self;
exception
  when others then
    perform uni_error.generate('UNI','EError','Ошибка при обновлении таблицы '||sp_schema||'.'||sp_table||'с ключом "'||idp_self||'"'||Chr(10)||sqlerrm);
end;$_$;


--
-- Name: set_table_field_value(public.t_name, public.t_name, public.t_name, public.t_id, public.t_id, public.t_name); Type: FUNCTION; Schema: uni_api; Owner: -
--

CREATE FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_id, sp_identityfield public.t_name) RETURNS void
    LANGUAGE plpgsql
    AS $_$
declare
  sv_query text := format('update %I.%I set %I = $1 where %I = $2', sp_schema, sp_table, sp_field, sp_identityfield);
begin
  execute sv_query using p_value, idp_self;
exception
  when others then
    perform uni_error.generate('UNI','EError','Ошибка при обновлении таблицы '||sp_schema||'.'||sp_table||'с ключом "'||idp_self||'"'||Chr(10)||sqlerrm);
end;
$_$;


--
-- Name: set_table_field_value(public.t_name, public.t_name, public.t_name, public.t_id, public.t_integer, public.t_name); Type: FUNCTION; Schema: uni_api; Owner: -
--

CREATE FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_integer, sp_identityfield public.t_name) RETURNS void
    LANGUAGE plpgsql
    AS $_$
declare
  sv_query text := format('update %I.%I set %I = $1 where %I = $2', sp_schema, sp_table, sp_field, sp_identityfield);
begin
  execute sv_query using p_value, idp_self;
exception
  when others then
    perform uni_error.generate('UNI','EError','Ошибка при обновлении таблицы '||sp_schema||'.'||sp_table||'с ключом "'||idp_self||'"'||Chr(10)||sqlerrm);
end;$_$;


--
-- Name: set_table_field_value(public.t_name, public.t_name, public.t_name, public.t_id, public.t_json, public.t_name); Type: FUNCTION; Schema: uni_api; Owner: -
--

CREATE FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_json, sp_identityfield public.t_name) RETURNS void
    LANGUAGE plpgsql
    AS $_$
declare
  sv_query text := format('update %I.%I set %I = $1 where %I = $2', sp_schema, sp_table, sp_field, sp_identityfield);
begin
  execute sv_query using p_value, idp_self;
exception
  when others then
    perform uni_error.generate('UNI','EError','Ошибка при обновлении таблицы '||sp_schema||'.'||sp_table||'с ключом "'||idp_self||'"'||Chr(10)||sqlerrm);
end;$_$;


--
-- Name: set_table_field_value(public.t_name, public.t_name, public.t_name, public.t_id, public.t_longstring, public.t_name); Type: FUNCTION; Schema: uni_api; Owner: -
--

CREATE FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_longstring, sp_identityfield public.t_name) RETURNS void
    LANGUAGE plpgsql
    AS $_$
declare
  sv_query text := format('update %I.%I set %I = $1 where %I = $2', sp_schema, sp_table, sp_field, sp_identityfield);
begin
  execute sv_query using p_value, idp_self;
exception
  when others then
    perform uni_error.generate('UNI','EError','Ошибка при обновлении таблицы '||sp_schema||'.'||sp_table||'с ключом "'||idp_self||'"'||Chr(10)||sqlerrm);
end;$_$;


--
-- Name: set_table_field_value(public.t_name, public.t_name, public.t_name, public.t_id, public.t_money, public.t_name); Type: FUNCTION; Schema: uni_api; Owner: -
--

CREATE FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_money, sp_identityfield public.t_name) RETURNS void
    LANGUAGE plpgsql
    AS $_$
declare
  sv_query text := format('update %I.%I set %I = $1 where %I = $2', sp_schema, sp_table, sp_field, sp_identityfield);
begin
  execute sv_query using p_value, idp_self;
exception
  when others then
    perform uni_error.generate('UNI','EError','Ошибка при обновлении таблицы '||sp_schema||'.'||sp_table||'с ключом "'||idp_self||'"'||Chr(10)||sqlerrm);
end;$_$;


--
-- Name: set_table_field_value(public.t_name, public.t_name, public.t_name, public.t_id, public.t_name, public.t_name); Type: FUNCTION; Schema: uni_api; Owner: -
--

CREATE FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_name, sp_identityfield public.t_name) RETURNS void
    LANGUAGE plpgsql
    AS $_$
declare
  sv_query text := format('update %I.%I set %I = $1 where %I = $2', sp_schema, sp_table, sp_field, sp_identityfield);
begin
  execute sv_query using p_value, idp_self;
exception
  when others then
    perform uni_error.generate('UNI','EError','Ошибка при обновлении таблицы '||sp_schema||'.'||sp_table||'с ключом "'||idp_self||'"'||Chr(10)||sqlerrm);
end;$_$;


--
-- Name: set_table_field_value(public.t_name, public.t_name, public.t_name, public.t_id, public.t_shortstring, public.t_name); Type: FUNCTION; Schema: uni_api; Owner: -
--

CREATE FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_shortstring, sp_identityfield public.t_name) RETURNS void
    LANGUAGE plpgsql
    AS $_$
declare
  sv_query text := format('update %I.%I set %I = $1 where %I = $2', sp_schema, sp_table, sp_field, sp_identityfield);
begin
  execute sv_query using p_value, idp_self;
exception
  when others then
    perform uni_error.generate('UNI','EError','Ошибка при обновлении таблицы '||sp_schema||'.'||sp_table||'с ключом "'||idp_self||'"'||Chr(10)||sqlerrm);
end;$_$;


--
-- Name: set_table_field_value(public.t_name, public.t_name, public.t_name, public.t_id, public.t_xml, public.t_name); Type: FUNCTION; Schema: uni_api; Owner: -
--

CREATE FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_xml, sp_identityfield public.t_name) RETURNS void
    LANGUAGE plpgsql
    AS $_$
declare
  sv_query text := format('update %I.%I set %I = $1 where %I = $2', sp_schema, sp_table, sp_field, sp_identityfield);
begin
  execute sv_query using p_value, idp_self;
exception
  when others then
    perform uni_error.generate('UNI','EError','Ошибка при обновлении таблицы '||sp_schema||'.'||sp_table||'с ключом "'||idp_self||'"'||Chr(10)||sqlerrm);
end;$_$;


--
-- Name: component__after_edit(public.t_id); Type: FUNCTION; Schema: uni_component; Owner: -
--

CREATE FUNCTION uni_component.component__after_edit(idp_self public.t_id) RETURNS void
    LANGUAGE plpgsql
    AS $$
begin
  perform uni_component.component__validate(idp_self);
end; $$;


--
-- Name: component__delete_record(public.t_id); Type: FUNCTION; Schema: uni_component; Owner: -
--

CREATE FUNCTION uni_component.component__delete_record(idp_self public.t_id) RETURNS void
    LANGUAGE plpgsql
    AS $$
begin
 delete from uni_component.component where id = idp_self;
end; $$;


--
-- Name: component__find_by_name(public.t_name); Type: FUNCTION; Schema: uni_component; Owner: -
--

CREATE FUNCTION uni_component.component__find_by_name(sp_name public.t_name) RETURNS public.t_id
    LANGUAGE plpgsql
    AS $$
declare
  nv_count t_integer := 0;
  idv_self t_id;
begin
  select count(*) into nv_count from uni_component.component t where t.s_name = sp_name;
  if nv_count > 1 then
    return 0;
  end if;
  select t.id into idv_self from uni_component.component t where t.s_name = sp_name;
  return idv_self;
end;
$$;


--
-- Name: component; Type: TABLE; Schema: uni_component; Owner: -
--

CREATE TABLE uni_component.component (
    id public.t_id NOT NULL,
    s_name public.t_name NOT NULL,
    s_caption public.t_caption,
    s_description public.t_description,
    id_parent public.t_id
);


--
-- Name: TABLE component; Type: COMMENT; Schema: uni_component; Owner: -
--

COMMENT ON TABLE uni_component.component IS 'Компоненты';


--
-- Name: COLUMN component.id; Type: COMMENT; Schema: uni_component; Owner: -
--

COMMENT ON COLUMN uni_component.component.id IS 'Код';


--
-- Name: COLUMN component.s_name; Type: COMMENT; Schema: uni_component; Owner: -
--

COMMENT ON COLUMN uni_component.component.s_name IS 'Системное имя';


--
-- Name: COLUMN component.s_caption; Type: COMMENT; Schema: uni_component; Owner: -
--

COMMENT ON COLUMN uni_component.component.s_caption IS 'Наименование';


--
-- Name: COLUMN component.s_description; Type: COMMENT; Schema: uni_component; Owner: -
--

COMMENT ON COLUMN uni_component.component.s_description IS 'Описание';


--
-- Name: COLUMN component.id_parent; Type: COMMENT; Schema: uni_component; Owner: -
--

COMMENT ON COLUMN uni_component.component.id_parent IS 'Код родительского компонента';


--
-- Name: component__get_row(public.t_id); Type: FUNCTION; Schema: uni_component; Owner: -
--

CREATE FUNCTION uni_component.component__get_row(idp_self public.t_id) RETURNS uni_component.component
    LANGUAGE sql
    AS $$
  select t.* from uni_component.component t where t.id = idp_self;
$$;


--
-- Name: component__insert_record(public.t_name); Type: FUNCTION; Schema: uni_component; Owner: -
--

CREATE FUNCTION uni_component.component__insert_record(sp_name public.t_name) RETURNS public.t_id
    LANGUAGE plpgsql
    AS $$
declare
 rv_row uni_component.component%rowtype;
begin
 rv_row.id := uni_api.get_table_id('uni_component','component');
 rv_row.s_name := sp_name;

 insert into uni_component.component(id, s_name)
 values(rv_row.id, rv_row.s_name);

 return rv_row.id;

end; $$;


--
-- Name: component__lock_record(public.t_id); Type: FUNCTION; Schema: uni_component; Owner: -
--

CREATE FUNCTION uni_component.component__lock_record(idp_self public.t_id) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare
 bv_is_ok t_boolean;
 sv_component_name t_name = 'UNI';
 sv_error_name t_name = 'ENoLockedRow';
begin
 select true into bv_is_ok from uni_component.component where id = idp_self for update nowait;
 exception when lock_not_available then
   perform uni_error.generate(sv_component_name, sv_error_name, idp_self::t_shortstring);
end; $$;


--
-- Name: component__set_caption(public.t_id, public.t_caption); Type: FUNCTION; Schema: uni_component; Owner: -
--

CREATE FUNCTION uni_component.component__set_caption(idp_self public.t_id, p_value public.t_caption) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare
  sv_schema_name t_name = 'uni_component';
  sv_table_name t_name = 'component';
  sv_column_name t_name = 's_caption';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: component__set_description(public.t_id, public.t_description); Type: FUNCTION; Schema: uni_component; Owner: -
--

CREATE FUNCTION uni_component.component__set_description(idp_self public.t_id, p_value public.t_description) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare
  sv_schema_name t_name = 'uni_component';
  sv_table_name t_name = 'component';
  sv_column_name t_name = 's_description';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: component__set_name(public.t_id, public.t_name); Type: FUNCTION; Schema: uni_component; Owner: -
--

CREATE FUNCTION uni_component.component__set_name(idp_self public.t_id, p_value public.t_name) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare
  sv_schema_name t_name = 'uni_component';
  sv_table_name t_name = 'component';
  sv_column_name t_name = 's_name';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: component__set_parent(public.t_id, public.t_id); Type: FUNCTION; Schema: uni_component; Owner: -
--

CREATE FUNCTION uni_component.component__set_parent(idp_self public.t_id, p_value public.t_id) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare
  sv_schema_name t_name = 'uni_component';
  sv_table_name t_name = 'component';
  sv_column_name t_name = 'id_parent';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: component__validate(public.t_id); Type: FUNCTION; Schema: uni_component; Owner: -
--

CREATE FUNCTION uni_component.component__validate(idp_self public.t_id) RETURNS void
    LANGUAGE plpgsql
    AS $$
begin
 null;
end; $$;


--
-- Name: endl(); Type: FUNCTION; Schema: uni_const; Owner: -
--

CREATE FUNCTION uni_const.endl() RETURNS character varying
    LANGUAGE sql IMMUTABLE LEAKPROOF
    AS $$
	select chr(10) as endl;
$$;


--
-- Name: max_date(); Type: FUNCTION; Schema: uni_const; Owner: -
--

CREATE FUNCTION uni_const.max_date() RETURNS public.t_date
    LANGUAGE sql IMMUTABLE LEAKPROOF
    AS $$
  select to_date('31.12.4096','dd.mm.yyyy')::t_date as d_date
$$;


--
-- Name: min_date(); Type: FUNCTION; Schema: uni_const; Owner: -
--

CREATE FUNCTION uni_const.min_date() RETURNS public.t_date
    LANGUAGE sql IMMUTABLE LEAKPROOF
    AS $$
  select to_date('01.01.0001','dd.mm.yyyy')::t_date as d_date
$$;


--
-- Name: reg_col_type(); Type: FUNCTION; Schema: uni_const; Owner: -
--

CREATE FUNCTION uni_const.reg_col_type() RETURNS character varying
    LANGUAGE sql IMMUTABLE LEAKPROOF
    AS $$
	select '^(\w{1,4})_(.+)' as regular;
$$;


--
-- Name: reg_replace(public.t_name); Type: FUNCTION; Schema: uni_const; Owner: -
--

CREATE FUNCTION uni_const.reg_replace(sp_prefix public.t_name) RETURNS character varying
    LANGUAGE sql IMMUTABLE LEAKPROOF
    AS $$
  select '\1'||Coalesce(sp_prefix,'p')||'_\2';
$$;


--
-- Name: error__after_edit(public.t_id); Type: FUNCTION; Schema: uni_error; Owner: -
--

CREATE FUNCTION uni_error.error__after_edit(idp_self public.t_id) RETURNS void
    LANGUAGE plpgsql
    AS $$
begin
  perform uni_error.error__validate(idp_self);
  update uni_error.error set d_edited = current_timestamp where id = idp_self;
end; $$;


--
-- Name: error__delete_record(public.t_id); Type: FUNCTION; Schema: uni_error; Owner: -
--

CREATE FUNCTION uni_error.error__delete_record(idp_self public.t_id) RETURNS void
    LANGUAGE plpgsql
    AS $$
begin
 delete from uni_error.error where id = idp_self;
end; $$;


--
-- Name: error__find_by_name(public.t_name); Type: FUNCTION; Schema: uni_error; Owner: -
--

CREATE FUNCTION uni_error.error__find_by_name(sp_name public.t_name) RETURNS public.t_id
    LANGUAGE plpgsql
    AS $$
declare
  nv_count t_integer := 0;
  idv_self t_id;
begin
  select count(*) into nv_count from uni_error.error t where t.s_name = sp_name;
  if nv_count > 1 then
    return 0;
  end if;
  select t.id into idv_self from uni_error.error t where t.s_name = sp_name;
  return idv_self;
end;
$$;


--
-- Name: error; Type: TABLE; Schema: uni_error; Owner: -
--

CREATE TABLE uni_error.error (
    id public.t_id NOT NULL,
    s_name public.t_name NOT NULL,
    s_caption public.t_caption,
    s_description public.t_description,
    d_created public.t_datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
    d_edited public.t_datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
    id_component public.t_id NOT NULL
);


--
-- Name: TABLE error; Type: COMMENT; Schema: uni_error; Owner: -
--

COMMENT ON TABLE uni_error.error IS 'Ошибки';


--
-- Name: COLUMN error.id; Type: COMMENT; Schema: uni_error; Owner: -
--

COMMENT ON COLUMN uni_error.error.id IS 'Код';


--
-- Name: COLUMN error.s_name; Type: COMMENT; Schema: uni_error; Owner: -
--

COMMENT ON COLUMN uni_error.error.s_name IS 'Системное имя';


--
-- Name: COLUMN error.s_caption; Type: COMMENT; Schema: uni_error; Owner: -
--

COMMENT ON COLUMN uni_error.error.s_caption IS 'Наименование';


--
-- Name: COLUMN error.s_description; Type: COMMENT; Schema: uni_error; Owner: -
--

COMMENT ON COLUMN uni_error.error.s_description IS 'Описание';


--
-- Name: COLUMN error.d_created; Type: COMMENT; Schema: uni_error; Owner: -
--

COMMENT ON COLUMN uni_error.error.d_created IS 'Дата создания';


--
-- Name: COLUMN error.d_edited; Type: COMMENT; Schema: uni_error; Owner: -
--

COMMENT ON COLUMN uni_error.error.d_edited IS 'Дата последнего редактирования';


--
-- Name: COLUMN error.id_component; Type: COMMENT; Schema: uni_error; Owner: -
--

COMMENT ON COLUMN uni_error.error.id_component IS 'Код компонента';


--
-- Name: error__get_row(public.t_id); Type: FUNCTION; Schema: uni_error; Owner: -
--

CREATE FUNCTION uni_error.error__get_row(idp_self public.t_id) RETURNS uni_error.error
    LANGUAGE sql
    AS $$
  select t.* from uni_error.error t where t.id = idp_self;
$$;


--
-- Name: error__insert_record(public.t_name, public.t_id); Type: FUNCTION; Schema: uni_error; Owner: -
--

CREATE FUNCTION uni_error.error__insert_record(sp_name public.t_name, idp_component public.t_id) RETURNS public.t_id
    LANGUAGE plpgsql
    AS $$
declare
 rv_row uni_error.error%rowtype;
begin
 rv_row.id := uni_api.get_table_id('uni_error','error');
 rv_row.s_name := sp_name;
 rv_row.id_component := idp_component;
 rv_row.d_created := now()::t_datetime;
 rv_row.d_edited := now()::t_datetime;

 insert into uni_error.error(id, s_name, id_component, d_created, d_edited)
 values(rv_row.id, rv_row.s_name, rv_row.id_component, rv_row.d_created, rv_row.d_edited);

 return rv_row.id;

end; $$;


--
-- Name: error__lock_record(public.t_id); Type: FUNCTION; Schema: uni_error; Owner: -
--

CREATE FUNCTION uni_error.error__lock_record(idp_self public.t_id) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare
 bv_is_ok t_boolean;
 sv_component_name t_name = 'UNI';
 sv_error_name t_name = 'ENoLockedRow';
begin
 select true into bv_is_ok from uni_error.error where id = idp_self for update nowait;
 exception when lock_not_available then
   perform uni_error.generate(sv_component_name, sv_error_name, idp_self::t_shortstring);
end; $$;


--
-- Name: error__set_caption(public.t_id, public.t_caption); Type: FUNCTION; Schema: uni_error; Owner: -
--

CREATE FUNCTION uni_error.error__set_caption(idp_self public.t_id, p_value public.t_caption) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare
  sv_schema_name t_name = 'uni_error';
  sv_table_name t_name = 'error';
  sv_column_name t_name = 's_caption';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: error__set_component(public.t_id, public.t_id); Type: FUNCTION; Schema: uni_error; Owner: -
--

CREATE FUNCTION uni_error.error__set_component(idp_self public.t_id, p_value public.t_id) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare
  sv_schema_name t_name = 'uni_error';
  sv_table_name t_name = 'error';
  sv_column_name t_name = 'id_component';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: error__set_created(public.t_id, public.t_datetime); Type: FUNCTION; Schema: uni_error; Owner: -
--

CREATE FUNCTION uni_error.error__set_created(idp_self public.t_id, p_value public.t_datetime) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare
  sv_schema_name t_name = 'uni_error';
  sv_table_name t_name = 'error';
  sv_column_name t_name = 'd_created';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: error__set_description(public.t_id, public.t_description); Type: FUNCTION; Schema: uni_error; Owner: -
--

CREATE FUNCTION uni_error.error__set_description(idp_self public.t_id, p_value public.t_description) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare
  sv_schema_name t_name = 'uni_error';
  sv_table_name t_name = 'error';
  sv_column_name t_name = 's_description';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: error__set_edited(public.t_id, public.t_datetime); Type: FUNCTION; Schema: uni_error; Owner: -
--

CREATE FUNCTION uni_error.error__set_edited(idp_self public.t_id, p_value public.t_datetime) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare
  sv_schema_name t_name = 'uni_error';
  sv_table_name t_name = 'error';
  sv_column_name t_name = 'd_edited';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: error__set_name(public.t_id, public.t_name); Type: FUNCTION; Schema: uni_error; Owner: -
--

CREATE FUNCTION uni_error.error__set_name(idp_self public.t_id, p_value public.t_name) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare
  sv_schema_name t_name = 'uni_error';
  sv_table_name t_name = 'error';
  sv_column_name t_name = 's_name';
  sv_identity_field t_name = 'id';
begin
 perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name,idp_self, p_value, sv_identity_field);
end; $$;


--
-- Name: error__validate(public.t_id); Type: FUNCTION; Schema: uni_error; Owner: -
--

CREATE FUNCTION uni_error.error__validate(idp_self public.t_id) RETURNS void
    LANGUAGE plpgsql
    AS $$
begin
 null;
end; $$;


--
-- Name: generate(public.t_name, public.t_name, public.t_shortstring[]); Type: FUNCTION; Schema: uni_error; Owner: -
--

CREATE FUNCTION uni_error.generate(sp_component public.t_name, sp_name public.t_name, VARIADIC params public.t_shortstring[]) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare
  sv_error text;
  param text;
begin
  -- Собираем данные из компонент таблицы с применением шаблонов ошибки
  begin
    select error.s_error_dc
    into sv_error
    from uni_error.component_errors error
    where Upper(error.s_component_mc) = Upper(sp_component)
      and Upper(error.s_error_mc) = Upper(sp_name);
  end;
  -- Если мы такого не нашли, то использовать первый параметр, как сообщение об ошибке
  if sv_error is null then
    sv_error := '%1';
  end if;
  -- Формируем по шаблону 
  declare
    nv_count t_integer := 1;
  begin
    foreach param in array params
    loop
      sv_error := Replace(sv_error, '%'||nv_count, param);
      raise notice '%',sv_error;
      nv_count := nv_count + 1;
    end loop;
  end;
  -- Закидываем со следующей строки стек вызова
  declare
    sv_stack text;
  begin
    GET DIAGNOSTICS sv_stack := PG_CONTEXT;
    sv_error := sv_error||Chr(10)||sv_stack;
    raise exception '%',sv_error;
  end;
end;$$;


--
-- Name: generate_after_edit(public.t_name, public.t_name); Type: FUNCTION; Schema: uni_generator; Owner: -
--

CREATE FUNCTION uni_generator.generate_after_edit(sp_schemaname public.t_name, sp_tablename public.t_name) RETURNS text
    LANGUAGE plpgsql
    AS $_$
declare
  sv_text text := '';
  sv_schemaname t_name := lower(sp_schemaname);
  sv_tablename t_name := lower(sp_tablename);
begin
  -- шапка функции
  sv_text := sv_text||format('create or replace function %I.%I__after_edit', sv_schemaname, sv_tablename);
  sv_text := sv_text||format('(idp_self %I.%I.id%%type)',sv_schemaname, sv_tablename)||uni_const.endl();
  -- Определение возвращаемого значения и языка функции
  begin
    sv_text := sv_text||'returns void'||uni_const.endl();
    sv_text := sv_text||'language plpgsql as $$'||uni_const.endl();
    sv_text := sv_text||format('/*<meta object="%I.%I__after_edit"',sv_schemaname, sv_tablename)||uni_const.endl();
    sv_text := sv_text||format('        title="Функция after_edit таблицы %I.%I"',sv_schemaname, sv_tablename)||uni_const.endl();
    sv_text := sv_text||format('        author="%I"',user)||uni_const.endl();
    sv_text := sv_text||format('        created=%I',to_char(now(),'dd.mm.yyyy'))||uni_const.endl();
    sv_text := sv_text||'        version="1.0"'||uni_const.endl();
    sv_text := sv_text||'        description="">'||uni_const.endl();
    sv_text := sv_text||'</meta>*/'||uni_const.endl();
  end;
  --begin
  declare
    sv_cred_time text;
  begin
    sv_text := sv_text||'begin'||uni_const.endl();
    sv_text := sv_text||format('  perform %I.%I__validate(idp_self);', sv_schemaname, sv_tablename)||uni_const.endl();
    begin
      select string_agg(db_tab_col.column_name||' = current_timestamp',',')
      into sv_cred_time
      from information_schema.columns db_tab_col
      where lower(db_tab_col.table_schema) = sv_schemaname
        and lower(db_tab_col.table_name) = sv_tablename
        and lower(db_tab_col.column_name) in ('d_edited');
    end;
    if Coalesce(sv_cred_time, 'None') != 'None' then
      sv_text := sv_text||format('  update %I.%I set '||sv_cred_time||' where id = idp_self;', sv_schemaname, sv_tablename)||uni_const.endl();
    end if;
  end;
  --end
  begin
    sv_text := sv_text||'end; $$;'||uni_const.endl()||uni_const.endl();
  end;
  return sv_text;
end;$_$;


--
-- Name: generate_delete_record(public.t_name, public.t_name); Type: FUNCTION; Schema: uni_generator; Owner: -
--

CREATE FUNCTION uni_generator.generate_delete_record(sp_schemaname public.t_name, sp_tablename public.t_name) RETURNS text
    LANGUAGE plpgsql
    AS $_$
declare
  sv_text text := '';
  sv_schemaname t_name := lower(sp_schemaname);
  sv_tablename t_name := lower(sp_tablename);
begin
  -- шапка функции
  sv_text := sv_text||format('create or replace function %I.%I__delete_record',sv_schemaname,sv_tablename);
  sv_text := sv_text||format('(idp_self %I.%I.id%%type)',sv_schemaname,sv_tablename)||uni_const.endl();
  -- Определение возвращаемого значения и языка функции
  begin
    sv_text := sv_text||'returns void'||uni_const.endl();
    sv_text := sv_text||'language plpgsql as $$'||uni_const.endl();
    sv_text := sv_text||format('/*<meta object="%I.%I__delete_record"',sv_schemaname, sv_tablename)||uni_const.endl();
    sv_text := sv_text||format('        title="Функция delete_record таблицы %I.%I"',sv_schemaname, sv_tablename)||uni_const.endl();
    sv_text := sv_text||format('        author="%I"',user)||uni_const.endl();
    sv_text := sv_text||format('        created=%I',to_char(now(),'dd.mm.yyyy'))||uni_const.endl();
    sv_text := sv_text||'        version="1.0"'||uni_const.endl();
    sv_text := sv_text||'        description="">'||uni_const.endl();
    sv_text := sv_text||'</meta>*/'||uni_const.endl();
  end;
  --begin
  begin
    sv_text := sv_text||'begin'||uni_const.endl();
    sv_text := sv_text||format(' delete from %I.%I where id = idp_self;',sp_schemaname,sp_tablename)||uni_const.endl();
  end;
  --end
  begin
    sv_text := sv_text||'end; $$;'||uni_const.endl()||uni_const.endl();
  end;
  return sv_text;
end;$_$;


--
-- Name: generate_find_by_code(public.t_name, public.t_name); Type: FUNCTION; Schema: uni_generator; Owner: -
--

CREATE FUNCTION uni_generator.generate_find_by_code(sp_schemaname public.t_name, sp_tablename public.t_name) RETURNS text
    LANGUAGE plpgsql
    AS $_$
declare
  sv_text text := '';
  sv_tablename t_name := lower(sp_tablename);
  sv_schemaname t_name := lower(sp_schemaname);
begin
  --sv_text := sv_text||'drop function '||sp_schemaname||'.'||sp_tablename||'_FindByName;'||uni_const.endl();
  -- шапка функции
  sv_text := sv_text||format('create or replace function %I.%I__find_by_code',sv_schemaname,sv_tablename);
  sv_text := sv_text||format('(sp_code %I.%I.s_code%%type)',sv_schemaname,sv_tablename)||uni_const.endl();
  -- Определение возвращаемого значения и языка функции
  begin
    sv_text := sv_text||format('returns %I.%I.id%%type',sv_schemaname,sv_tablename)||uni_const.endl();
    sv_text := sv_text||'language plpgsql as $$'||uni_const.endl();
    sv_text := sv_text||format('/*<meta object="%I.%I__find_by_code"',sv_schemaname, sv_tablename)||uni_const.endl();
    sv_text := sv_text||format('        title="Функция find_by_code таблицы %I.%I"',sv_schemaname, sv_tablename)||uni_const.endl();
    sv_text := sv_text||format('        author="%I"',user)||uni_const.endl();
    sv_text := sv_text||format('        created=%I',to_char(now(),'dd.mm.yyyy'))||uni_const.endl();
    sv_text := sv_text||'        version="1.0"'||uni_const.endl();
    sv_text := sv_text||'        description="">'||uni_const.endl();
    sv_text := sv_text||'</meta>*/'||uni_const.endl();
  end;
  -- declare
  sv_text := sv_text||'declare'||uni_const.endl();
  sv_text := sv_text||'  nv_count t_integer := 0;'||uni_const.endl();
  sv_text := sv_text||'  idv_self t_id;'||uni_const.endl();
  -- begin
  sv_text := sv_text||'begin'||uni_const.endl();
  sv_text := sv_text||format('  select count(*) into nv_count from %I.%I t where t.s_code = sp_code;',sv_schemaname,sv_tablename)||uni_const.endl();
  sv_text := sv_text||'  if nv_count > 1 then'||uni_const.endl();
  sv_text := sv_text||'    return 0;'||uni_const.endl();
  sv_text := sv_text||'  end if;'||uni_const.endl();
  sv_text := sv_text||format('  select t.id into idv_self from %I.%I t where t.s_code = sp_code;',sv_schemaname,sv_tablename)||uni_const.endl();
  sv_text := sv_text||'  return idv_self;'||uni_const.endl();
  --end
  sv_text := sv_text||'end;'||uni_const.endl();
  begin
    sv_text := sv_text||'$$;'||uni_const.endl()||uni_const.endl();
  end;
  return sv_text;
end; 
$_$;


--
-- Name: generate_find_by_name(public.t_name, public.t_name); Type: FUNCTION; Schema: uni_generator; Owner: -
--

CREATE FUNCTION uni_generator.generate_find_by_name(sp_schemaname public.t_name, sp_tablename public.t_name) RETURNS text
    LANGUAGE plpgsql
    AS $_$
declare
  sv_text text := '';
  sv_schemaname t_name := lower(sp_schemaname);
  sv_tablename t_name := lower(sp_tablename);
begin
  --sv_text := sv_text||'drop function '||sp_schemaname||'.'||sp_tablename||'_FindByName;'||uni_const.endl();
  -- шапка функции
  sv_text := sv_text||format('create or replace function %I.%I__find_by_name',sv_schemaname,sv_tablename);
  sv_text := sv_text||format('(sp_name %I.%I.s_name%%type)',sv_schemaname,sv_tablename)||uni_const.endl();
  -- Определение возвращаемого значения и языка функции
  begin
    sv_text := sv_text||format('returns %I.%I.id%%type',sv_schemaname,sv_tablename)||uni_const.endl();
    sv_text := sv_text||'language plpgsql as $$'||uni_const.endl();
    sv_text := sv_text||format('/*<meta object="%I.%I__find_by_name"',sv_schemaname, sv_tablename)||uni_const.endl();
    sv_text := sv_text||format('        title="Функция find_by_name таблицы %I.%I"',sv_schemaname, sv_tablename)||uni_const.endl();
    sv_text := sv_text||format('        author="%I"',user)||uni_const.endl();
    sv_text := sv_text||format('        created=%I',to_char(now(),'dd.mm.yyyy'))||uni_const.endl();
    sv_text := sv_text||'        version="1.0"'||uni_const.endl();
    sv_text := sv_text||'        description="">'||uni_const.endl();
    sv_text := sv_text||'</meta>*/'||uni_const.endl();
  end;
  -- declare
  sv_text := sv_text||'declare'||uni_const.endl();
  sv_text := sv_text||'  nv_count t_integer := 0;'||uni_const.endl();
  sv_text := sv_text||'  idv_self t_id;'||uni_const.endl();
  -- begin
  sv_text := sv_text||'begin'||uni_const.endl();
  sv_text := sv_text||format('  select count(*) into nv_count from %I.%I t where t.s_name = sp_name;',sv_schemaname,sv_tablename)||uni_const.endl();
  sv_text := sv_text||'  if nv_count > 1 then'||uni_const.endl();
  sv_text := sv_text||'    return 0;'||uni_const.endl();
  sv_text := sv_text||'  end if;'||uni_const.endl();
  sv_text := sv_text||format('  select t.id into idv_self from %I.%I t where t.s_name = sp_name;',sv_schemaname,sv_tablename)||uni_const.endl();
  --end
  sv_text := sv_text||'  return idv_self;'||uni_const.endl();
  sv_text := sv_text||'end;'||uni_const.endl();
  begin
    sv_text := sv_text||'$$;'||uni_const.endl()||uni_const.endl();
  end;
  return sv_text;
end; 
$_$;


--
-- Name: generate_get_row(public.t_name, public.t_name); Type: FUNCTION; Schema: uni_generator; Owner: -
--

CREATE FUNCTION uni_generator.generate_get_row(sp_schemaname public.t_name, sp_tablename public.t_name) RETURNS text
    LANGUAGE plpgsql
    AS $_$
declare
  sv_text text := '';
  sv_schemaname t_name := lower(sp_schemaname);
  sv_tablename t_name := lower(sp_tablename);
begin
  -- шапка функции
  sv_text := sv_text||format('create or replace function %I.%I__get_row',sv_schemaname,sv_tablename);
  sv_text := sv_text||format('(idp_self %I.%I.id%%Type)',sv_schemaname,sv_tablename)||uni_const.endl();
  -- Определение возвращаемого значения и языка функции
  begin
    sv_text := sv_text||format('returns %I.%I',sv_schemaname,sv_tablename)||uni_const.endl();
    sv_text := sv_text||'language sql as $$'||uni_const.endl();
    sv_text := sv_text||format('/*<meta object="%I.%I__get_row"',sv_schemaname, sv_tablename)||uni_const.endl();
    sv_text := sv_text||format('        title="Функция get_row таблицы %I.%I"',sv_schemaname, sv_tablename)||uni_const.endl();
    sv_text := sv_text||format('        author="%I"',user)||uni_const.endl();
    sv_text := sv_text||format('        created=%I',to_char(now(),'dd.mm.yyyy'))||uni_const.endl();
    sv_text := sv_text||'        version="1.0"'||uni_const.endl();
    sv_text := sv_text||'        description="">'||uni_const.endl();
    sv_text := sv_text||'</meta>*/'||uni_const.endl();
  end;
  --declare
  begin
    sv_text := sv_text||format('  select t.* from %I.%I t where t.id = idp_self;',sv_schemaname,sv_tablename)||uni_const.endl();
  end;
  --end
  begin
    sv_text := sv_text||'$$;'||uni_const.endl()||uni_const.endl();
  end;
  return sv_text;
end; $_$;


--
-- Name: generate_grants(public.t_name, public.t_name, public.t_shortstringarray); Type: FUNCTION; Schema: uni_generator; Owner: -
--

CREATE FUNCTION uni_generator.generate_grants(sp_schemaname public.t_name, sp_tablename public.t_name, sap_roles public.t_shortstringarray) RETURNS text
    LANGUAGE plpgsql
    AS $$
declare
  sv_text text := '';
  sv_schemanname t_name := lower(sp_schemaname);
  sv_tablename t_name := lower(sp_tablename);
  curv_data record;
  grant_role t_shortstring;
begin
  for curv_data in
  (
    select NSP.nspname as s_schemaname
          ,Proc.proName as s_procname
          ,pg_catalog.pg_get_function_identity_arguments(Proc.oid) as s_procparams
    from pg_catalog.pg_namespace NSP
    inner join pg_catalog.pg_proc Proc on Proc.pronamespace = NSP.oid
    where lower(NSP.nspname) = sv_schemanname
      and lower(Proc.proname) like sv_tablename||'_%'
  )
  loop
    foreach grant_role in array sap_roles::character varying(255)[]
    loop
      sv_text := sv_text||format('grant execute on function %I.%I(%s) to %I;',curv_data.s_schemaname,curv_data.s_procname, curv_data.s_procparams, grant_role)||uni_const.endl();
    end loop;
  end loop;
  return sv_text;
end;$$;


--
-- Name: generate_insert_record(public.t_name, public.t_name); Type: FUNCTION; Schema: uni_generator; Owner: -
--

CREATE FUNCTION uni_generator.generate_insert_record(sp_schemaname public.t_name, sp_tablename public.t_name) RETURNS text
    LANGUAGE plpgsql
    AS $_$
declare
  sv_text text := '';
  sv_schemaname t_name := lower(sp_schemaname);
  sv_tablename t_name := lower(sp_tablename);
begin
  -- шапка функции
  sv_text := sv_text||format('create or replace function %I.%I__insert_record',sv_schemaname,sv_tablename);
  -- Необходимые параметры (not null)
  declare
    curv_column record;
  begin
    -- Открываем блок параметров
    sv_text := sv_text||uni_const.endl()||'('||uni_const.endl();
    for curv_column in
      select row_number() over() as rownum
            ,count(*) over() as all_count
            ,db_tab_col.*
      from information_schema.columns db_tab_col
      where lower(db_tab_col.table_schema) = sv_schemaname
        and lower(db_tab_col.table_name) = sv_tablename
        and lower(db_tab_col.column_name) not in('id','d_created','d_edited')
        and db_tab_col.column_default is null
        and db_tab_col.is_nullable = 'NO'
    loop
      sv_text := sv_text||' '||case when curv_column.rownum = 1 then ' '
                               else ',' end
                        ||regexp_replace(curv_column.column_name
                                        ,uni_const.reg_col_type()
                                        ,uni_const.reg_replace('p'))
                        ||' '
                        ||format('%I.%I.%I%%type',sp_schemaname,sp_tablename,curv_column.column_name)
                        ||case when curv_column.rownum = curv_column.all_count then ''
                          else uni_const.endl() end;
    end loop;
    -- закрываем блок параметров
    sv_text := sv_text||uni_const.endl()||')'||uni_const.endl();
  end;
  -- Определение возвращаемого значения и языка функции
  begin
    sv_text := sv_text||format(' returns %I.%I.id%%type',sv_schemaname,sv_tablename)||uni_const.endl();
    sv_text := sv_text||'language plpgsql as $$'||uni_const.endl();
    sv_text := sv_text||format('/*<meta object="%I.%I__insert_record"',sv_schemaname, sv_tablename)||uni_const.endl();
    sv_text := sv_text||format('        title="Функция insert_record таблицы %I.%I"',sv_schemaname, sv_tablename)||uni_const.endl();
    sv_text := sv_text||format('        author="%I"',user)||uni_const.endl();
    sv_text := sv_text||format('        created=%I',to_char(now(),'dd.mm.yyyy'))||uni_const.endl();
    sv_text := sv_text||'        version="1.0"'||uni_const.endl();
    sv_text := sv_text||'        description="">'||uni_const.endl();
    sv_text := sv_text||'</meta>*/'||uni_const.endl();
  end;
  --Тело функции
  --declare
  begin
    sv_text := sv_text||'declare'||uni_const.endl();
    sv_text := sv_text||format(' rv_row %I.%I%%rowtype;',sv_schemaname,sv_tablename)||uni_const.endl();
  end;
  --begin
  declare
    curv_column record;
  begin
    sv_text := sv_text||'begin'||uni_const.endl();
    -- Устанавливаем все системные поля и поля которые нужны для инсерта
    sv_text := sv_text||format(' rv_row.id := uni_api.get_table_id(''%I'',''%I'');',sv_schemaname,sv_tablename)||uni_const.endl();
    for curv_column in
      select row_number() over() as rownum
            ,count(*) over() as all_count
            ,db_tab_col.*
      from information_schema.columns db_tab_col
      where lower(db_tab_col.table_schema) = sv_schemaname
        and lower(db_tab_col.table_name) = sv_tablename
        and lower(db_tab_col.column_name) not in('id','d_created','d_edited')
        and db_tab_col.column_default is null
        and db_tab_col.is_nullable = 'NO'
    loop
      sv_text := sv_text||format(' rv_row.%I := %I;',curv_column.column_name,regexp_replace(curv_column.column_name
                                                                                          ,uni_const.reg_col_type()
                                                                                          ,uni_const.reg_replace('p')))
                        ||uni_const.endl();
    end loop;
    -- Добрасываем редактирование дат создани я редактирования
    for curv_column in
      select row_number() over() as rownum
            ,count(*) over() as all_count
            ,db_tab_col.*
      from information_schema.columns db_tab_col
      where lower(db_tab_col.table_schema) = sv_schemaname
        and lower(db_tab_col.table_name) = sv_tablename
        and lower(db_tab_col.column_name) in('d_created','d_edited')
    loop
      sv_text := sv_text||format(' rv_row.%I := now()::t_datetime;',curv_column.column_name)
                        ||uni_const.endl();
    end loop;
    -- Пишем вставку
    sv_text := sv_text||uni_const.endl();
    sv_text := sv_text||format(' insert into %I.%I(id',sv_schemaname,sv_tablename);
    for curv_column in
      select row_number() over() as rownum
            ,count(*) over() as all_count
            ,db_tab_col.*
      from information_schema.columns db_tab_col
      where lower(db_tab_col.table_schema) = sv_schemaname
        and lower(db_tab_col.table_name) = sv_tablename
        and lower(db_tab_col.column_name) not in('id','d_created','d_edited')
        and db_tab_col.column_default is null
        and db_tab_col.is_nullable = 'NO'
    loop
      sv_text := sv_text||', '||curv_column.column_name;
    end loop;
    for curv_column in
      select row_number() over() as rownum
            ,count(*) over() as all_count
            ,db_tab_col.*
      from information_schema.columns db_tab_col
      where lower(db_tab_col.table_schema) = sv_schemaname
        and lower(db_tab_col.table_name) = sv_tablename
        and lower(db_tab_col.column_name) in('d_created','d_edited')
    loop
      sv_text := sv_text||', '||curv_column.column_name;
    end loop;
    sv_text := sv_text||')'||uni_const.endl();
    sv_text := sv_text||' values(rv_row.id';
    for curv_column in
      select row_number() over() as rownum
            ,count(*) over() as all_count
            ,db_tab_col.*
      from information_schema.columns db_tab_col
      where lower(db_tab_col.table_schema) = sv_schemaname
        and lower(db_tab_col.table_name) = sv_tablename
        and lower(db_tab_col.column_name) not in('id','d_created','d_edited')
        and db_tab_col.column_default is null
        and db_tab_col.is_nullable = 'NO'
    loop
      sv_text := sv_text||', rv_row.'||curv_column.column_name;
    end loop;
    for curv_column in
      select row_number() over() as rownum
            ,count(*) over() as all_count
            ,db_tab_col.*
      from information_schema.columns db_tab_col
      where lower(db_tab_col.table_schema) = sv_schemaname
        and lower(db_tab_col.table_name) = sv_tablename
        and lower(db_tab_col.column_name) in('d_created','d_edited')
    loop
      sv_text := sv_text||', rv_row.'||curv_column.column_name;
    end loop;
    sv_text := sv_text||');'||uni_const.endl();
    sv_text := sv_text||uni_const.endl();
    sv_text := sv_text||' return rv_row.id;'||uni_const.endl();
    sv_text := sv_text||uni_const.endl();
  end;
  --end
  begin
    sv_text := sv_text||'end; $$;'||uni_const.endl()||uni_const.endl();
  end;
  -- Возвращаем значение заготовки
  return sv_text;
end;$_$;


--
-- Name: generate_lock_record(public.t_name, public.t_name); Type: FUNCTION; Schema: uni_generator; Owner: -
--

CREATE FUNCTION uni_generator.generate_lock_record(sp_schemaname public.t_name, sp_tablename public.t_name) RETURNS text
    LANGUAGE plpgsql
    AS $_$
declare
  sv_text text := '';
  sv_schemaname t_name := lower(sp_schemaname);
  sv_tablename t_name := lower(sp_tablename);
begin
  -- шапка функции
  sv_text := sv_text||format('create or replace function %I.%I__lock_record',sv_schemaname,sv_tablename);
  sv_text := sv_text||format('(idp_self %I.%I.id%%type)',sv_schemaname,sv_tablename)||uni_const.endl();
  -- Определение возвращаемого значения и языка функции
  begin
    sv_text := sv_text||'returns void'||uni_const.endl();
    sv_text := sv_text||'language plpgsql as $$'||uni_const.endl();
    sv_text := sv_text||format('/*<meta object="%I.%I__lock_record"',sv_schemaname, sv_tablename)||uni_const.endl();
    sv_text := sv_text||format('        title="Функция lock_record таблицы %I.%I"',sv_schemaname, sv_tablename)||uni_const.endl();
    sv_text := sv_text||format('        author="%I"',user)||uni_const.endl();
    sv_text := sv_text||format('        created=%I',to_char(now(),'dd.mm.yyyy'))||uni_const.endl();
    sv_text := sv_text||'        version="1.0"'||uni_const.endl();
    sv_text := sv_text||'        description="">'||uni_const.endl();
    sv_text := sv_text||'</meta>*/'||uni_const.endl();
  end;
  --declare
  begin
    sv_text := sv_text||'declare'||uni_const.endl();
    sv_text := sv_text||' bv_is_ok t_boolean;'||uni_const.endl();
    sv_text := sv_text||' sv_component_name t_name = ''UNI'';'||uni_const.endl();
    sv_text := sv_text||' sv_error_name t_name = ''ENoLockedRow'';'||uni_const.endl();
  end;
  --begin
  begin
    sv_text := sv_text||'begin'||uni_const.endl();
    sv_text := sv_text||format(' select true into bv_is_ok from %I.%I where id = idp_self for update nowait;',sv_schemaname,sv_tablename)||uni_const.endl();
    sv_text := sv_text||' exception when lock_not_available then'||uni_const.endl();
    sv_text := sv_text||'   perform uni_error.generate(sv_component_name, sv_error_name, idp_self::t_shortstring);'||uni_const.endl();
  end;
  --end
  begin
    sv_text := sv_text||'end; $$;'||uni_const.endl()||uni_const.endl();
  end;
  return sv_text;
end;$_$;


--
-- Name: generate_setters(public.t_name, public.t_name); Type: FUNCTION; Schema: uni_generator; Owner: -
--

CREATE FUNCTION uni_generator.generate_setters(sp_schemaname public.t_name, sp_tablename public.t_name) RETURNS text
    LANGUAGE plpgsql
    AS $_$
declare
  sv_text text := '';
  sv_schemaname t_name := lower(sp_schemaname);
  sv_tablename t_name := lower(sp_tablename);
  curv_column record;
begin
  for curv_column in
    select row_number() over() as rownum
          ,count(*) over() as all_count
          ,db_tab_col.*
    from information_schema.columns db_tab_col
    where lower(db_tab_col.table_schema) = sv_schemaname
      and lower(db_tab_col.table_name) = sv_tablename
      and lower(db_tab_col.column_name) not in('id')
  loop
    sv_text := sv_text||'create or replace function '||sv_schemaname||'.'||sv_tablename
                      ||'__set_'||lower(regexp_replace(curv_column.column_name
                                                      ,uni_const.reg_col_type()
                                                      ,'\2'));
    sv_text := sv_text||'(idp_self '||sp_schemaname||'.'||sp_tablename||'.id%type,'
                      ||' p_value '||sp_schemaname||'.'||sp_tablename||'.'||curv_column.column_name||'%type,'
                      ||' bp_internal_call t_boolean default false)'||uni_const.endl();
    -- Определение возвращаемого значения и языка функции
    begin
      sv_text := sv_text||'returns void'||uni_const.endl();
      sv_text := sv_text||'language plpgsql as $$'||uni_const.endl();
      sv_text := sv_text||format('/*<meta object="%I.%I__set_'||lower(regexp_replace(curv_column.column_name
                                                      ,uni_const.reg_col_type()
                                                      ,'\2'))||'"',sv_schemaname, sv_tablename)||uni_const.endl();
      sv_text := sv_text||format('        title="Функция setter для колонки "%I" таблицы %I.%I"',curv_column.column_name,sv_schemaname, sv_tablename)||uni_const.endl();
      sv_text := sv_text||format('        author="%I"',user)||uni_const.endl();
      sv_text := sv_text||format('        created=%I',to_char(now(),'dd.mm.yyyy'))||uni_const.endl();
      sv_text := sv_text||'        version="1.0"'||uni_const.endl();
      sv_text := sv_text||'        description="">'||uni_const.endl();
      sv_text := sv_text||'</meta>*/'||uni_const.endl();
    end;
    --declare
    begin
      sv_text := sv_text||'declare'||uni_const.endl();
      sv_text := sv_text||'  sv_schema_name t_name = '''||sv_schemaname||''';'||uni_const.endl();
      sv_text := sv_text||'  sv_table_name t_name = '''||sv_tablename||''';'||uni_const.endl();
      sv_text := sv_text||'  sv_column_name t_name = '''||curv_column.column_name||''';'||uni_const.endl();
      sv_text := sv_text||'  sv_identity_field t_name = ''id'';'||uni_const.endl();
    end;
    --begin
    begin
      sv_text := sv_text||'begin'||uni_const.endl();
      sv_text := sv_text||' perform uni_api.set_table_field_value(sv_schema_name, sv_table_name, sv_column_name';
      sv_text := sv_text||',idp_self, p_value, sv_identity_field);'||uni_const.endl();
    end;
    --end
    begin
      sv_text := sv_text||'end; $$;'||uni_const.endl()||uni_const.endl();
    end;
  end loop;
  return sv_text;
end;$_$;


--
-- Name: generate_table_api(public.t_name, public.t_name); Type: FUNCTION; Schema: uni_generator; Owner: -
--

CREATE FUNCTION uni_generator.generate_table_api(sp_schemaname public.t_name, sp_tablename public.t_name) RETURNS text
    LANGUAGE plpgsql
    AS $_$
declare
  sv_text text := '';
begin
  --Do
  sv_text := sv_text||'do'||uni_const.endl()||'$DO$'||uni_const.endl();
  sv_text := sv_text||'begin'||uni_const.endl();
  -- GetRow
  sv_text := sv_text||uni_generator.generate_get_row(sp_schemaname, sp_tablename);
  -- FindByName
  declare
    bv_exists_name t_boolean;
  begin
    begin
      select true
      into bv_exists_name
      from information_schema.columns db_tab_col
      where lower(db_tab_col.table_schema) = lower(sp_schemaname)
        and lower(db_tab_col.table_name) = lower(sp_tablename)
        and lower(db_tab_col.column_name) in ('s_name');
    end;
    if Coalesce(bv_exists_name, false) = true then
      sv_text := sv_text||uni_generator.generate_find_by_name(sp_schemaname, sp_tablename);
    end if;
  end;
  -- FindByCode
  declare
    bv_exists_code t_boolean;
  begin
    begin
      select true
      into bv_exists_code
      from information_schema.columns db_tab_col
      where lower(db_tab_col.table_schema) = lower(sp_schemaname)
        and lower(db_tab_col.table_name) = lower(sp_tablename)
        and lower(db_tab_col.column_name) in ('s_code');
    end;
    if Coalesce(bv_exists_code, false) = true then
      sv_text := sv_text||uni_generator.generate_find_by_code(sp_schemaname, sp_tablename);
    end if;
  end;
  -- LockRecord
  sv_text := sv_text||uni_generator.generate_lock_record(sp_schemaname, sp_tablename);
  -- InsertRecord
  sv_text := sv_text||uni_generator.generate_insert_record(sp_schemaname, sp_tablename); 
  -- DeleteRecord
  sv_text := sv_text||uni_generator.generate_delete_record(sp_schemaname, sp_tablename);
  -- Setters
  sv_text := sv_text||uni_generator.generate_setters(sp_schemaname, sp_tablename);
  -- Validate
  sv_text := sv_text||uni_generator.generate_validate(sp_schemaname, sp_tablename);
  -- AfterEdit
  sv_text := sv_text||uni_generator.generate_after_edit(sp_schemaname, sp_tablename);
  sv_text := sv_text||'end;'||uni_const.endl();
  sv_text := sv_text||'$DO$;';
  return sv_text;

end;$_$;


--
-- Name: generate_validate(public.t_name, public.t_name); Type: FUNCTION; Schema: uni_generator; Owner: -
--

CREATE FUNCTION uni_generator.generate_validate(sp_schemaname public.t_name, sp_tablename public.t_name) RETURNS text
    LANGUAGE plpgsql
    AS $_$
declare
  sv_text text := '';
  sv_schemaname t_name := lower(sp_schemaname);
  sv_tablename t_name := lower(sp_tablename);
begin
  -- шапка функции
  sv_text := sv_text||format('create or replace function %I.%I__validate',sv_schemaname,sv_tablename);
  sv_text := sv_text||format('(idp_self %I.%I.id%%type)',sv_schemaname,sv_tablename)||uni_const.endl();
  -- Определение возвращаемого значения и языка функции
  begin
    sv_text := sv_text||'returns void'||uni_const.endl();
    sv_text := sv_text||'language plpgsql as $$'||uni_const.endl();
    sv_text := sv_text||format('/*<meta object="%I.%I__validate"',sv_schemaname, sv_tablename)||uni_const.endl();
    sv_text := sv_text||format('        title="Функция validate таблицы %I.%I"',sv_schemaname, sv_tablename)||uni_const.endl();
    sv_text := sv_text||format('        author="%I"',user)||uni_const.endl();
    sv_text := sv_text||format('        created=%I',to_char(now(),'dd.mm.yyyy'))||uni_const.endl();
    sv_text := sv_text||'        version="1.0"'||uni_const.endl();
    sv_text := sv_text||'        description="">'||uni_const.endl();
    sv_text := sv_text||'</meta>*/'||uni_const.endl();
  end;
  --begin
  begin
    sv_text := sv_text||'begin'||uni_const.endl();
    sv_text := sv_text||' null;'||uni_const.endl();
  end;
  --end
  begin
    sv_text := sv_text||'end; $$;'||uni_const.endl()||uni_const.endl();
  end;
  return sv_text;
end;$_$;


--
-- Name: seq_doc; Type: SEQUENCE; Schema: cmn_doc; Owner: -
--

CREATE SEQUENCE cmn_doc.seq_doc
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: seq_doc_item; Type: SEQUENCE; Schema: cmn_doc; Owner: -
--

CREATE SEQUENCE cmn_doc.seq_doc_item
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: seq_component; Type: SEQUENCE; Schema: uni_component; Owner: -
--

CREATE SEQUENCE uni_component.seq_component
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: component_errors; Type: VIEW; Schema: uni_error; Owner: -
--

CREATE VIEW uni_error.component_errors AS
 WITH RECURSIVE componentall AS (
         SELECT componentin.id AS idroot,
            componentin.id,
            componentin.s_name AS sname,
            componentin.s_caption AS scaption
           FROM uni_component.component componentin
        UNION ALL
         SELECT componentall.idroot,
            componentin.id,
            componentin.s_name AS sname,
            componentin.s_caption AS scaption
           FROM (uni_component.component componentin
             JOIN componentall ON (((componentall.id)::bigint = (componentin.id_parent)::bigint)))
        )
 SELECT component.id AS id_component,
    component.sname AS s_component_mc,
    component.scaption AS s_component_hl,
    error.id AS id_error,
    error.s_name AS s_error_mc,
    error.s_caption AS s_error_hl,
    error.s_description AS s_error_dc
   FROM (componentall component
     LEFT JOIN uni_error.error error ON (((error.id_component)::bigint = (component.idroot)::bigint)));


--
-- Name: seq_error; Type: SEQUENCE; Schema: uni_error; Owner: -
--

CREATE SEQUENCE uni_error.seq_error
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Data for Name: doc; Type: TABLE DATA; Schema: cmn_doc; Owner: -
--

COPY cmn_doc.doc (id, s_number, d_date, f_sum, s_description) FROM stdin;
\.
COPY cmn_doc.doc (id, s_number, d_date, f_sum, s_description) FROM '$$PATH$$/3095.dat';

--
-- Data for Name: doc_item; Type: TABLE DATA; Schema: cmn_doc; Owner: -
--

COPY cmn_doc.doc_item (id, id_doc, s_number, s_caption, f_sum, n_order) FROM stdin;
\.
COPY cmn_doc.doc_item (id, id_doc, s_number, s_caption, f_sum, n_order) FROM '$$PATH$$/3097.dat';

--
-- Data for Name: component; Type: TABLE DATA; Schema: uni_component; Owner: -
--

COPY uni_component.component (id, s_name, s_caption, s_description, id_parent) FROM stdin;
\.
COPY uni_component.component (id, s_name, s_caption, s_description, id_parent) FROM '$$PATH$$/3091.dat';

--
-- Data for Name: error; Type: TABLE DATA; Schema: uni_error; Owner: -
--

COPY uni_error.error (id, s_name, s_caption, s_description, d_created, d_edited, id_component) FROM stdin;
\.
COPY uni_error.error (id, s_name, s_caption, s_description, d_created, d_edited, id_component) FROM '$$PATH$$/3092.dat';

--
-- Name: seq_doc; Type: SEQUENCE SET; Schema: cmn_doc; Owner: -
--

SELECT pg_catalog.setval('cmn_doc.seq_doc', 8, true);


--
-- Name: seq_doc_item; Type: SEQUENCE SET; Schema: cmn_doc; Owner: -
--

SELECT pg_catalog.setval('cmn_doc.seq_doc_item', 13, true);


--
-- Name: seq_component; Type: SEQUENCE SET; Schema: uni_component; Owner: -
--

SELECT pg_catalog.setval('uni_component.seq_component', 9, true);


--
-- Name: seq_error; Type: SEQUENCE SET; Schema: uni_error; Owner: -
--

SELECT pg_catalog.setval('uni_error.seq_error', 23, true);


--
-- Name: udx_doc_number_date; Type: INDEX; Schema: cmn_doc; Owner: -
--

CREATE UNIQUE INDEX udx_doc_number_date ON cmn_doc.doc USING btree (s_number, d_date);


--
-- Name: doc pk_doc; Type: CONSTRAINT; Schema: cmn_doc; Owner: -
--

ALTER TABLE ONLY cmn_doc.doc
    ADD CONSTRAINT pk_doc PRIMARY KEY (id);


--
-- Name: doc_item pk_doc_item; Type: CONSTRAINT; Schema: cmn_doc; Owner: -
--

ALTER TABLE ONLY cmn_doc.doc_item
    ADD CONSTRAINT pk_doc_item PRIMARY KEY (id);


--
-- Name: component pk_component_id; Type: CONSTRAINT; Schema: uni_component; Owner: -
--

ALTER TABLE ONLY uni_component.component
    ADD CONSTRAINT pk_component_id PRIMARY KEY (id);


--
-- Name: error pk_defaulterror; Type: CONSTRAINT; Schema: uni_error; Owner: -
--

ALTER TABLE ONLY uni_error.error
    ADD CONSTRAINT pk_defaulterror PRIMARY KEY (id);


--
-- Name: idx_doc_item_id_doc; Type: INDEX; Schema: cmn_doc; Owner: -
--

CREATE INDEX idx_doc_item_id_doc ON cmn_doc.doc_item USING btree (id_doc);


--
-- Name: idx_component_component_parent; Type: INDEX; Schema: uni_component; Owner: -
--

CREATE INDEX idx_component_component_parent ON uni_component.component USING btree (id_parent);


--
-- Name: idx_component_sname; Type: INDEX; Schema: uni_component; Owner: -
--

CREATE UNIQUE INDEX idx_component_sname ON uni_component.component USING btree (s_name);


--
-- Name: error_id_component_idx; Type: INDEX; Schema: uni_error; Owner: -
--

CREATE INDEX error_id_component_idx ON uni_error.error USING btree (id_component);


--
-- Name: idx_defaulterror_unq_name; Type: INDEX; Schema: uni_error; Owner: -
--

CREATE UNIQUE INDEX idx_defaulterror_unq_name ON uni_error.error USING btree (s_name);


--
-- Name: doc_item fk_doc_item_id_doc; Type: FK CONSTRAINT; Schema: cmn_doc; Owner: -
--

ALTER TABLE ONLY cmn_doc.doc_item
    ADD CONSTRAINT fk_doc_item_id_doc FOREIGN KEY (id_doc) REFERENCES cmn_doc.doc(id) ON DELETE CASCADE;


--
-- Name: component fk_component_component_parent; Type: FK CONSTRAINT; Schema: uni_component; Owner: -
--

ALTER TABLE ONLY uni_component.component
    ADD CONSTRAINT fk_component_component_parent FOREIGN KEY (id_parent) REFERENCES uni_component.component(id) ON DELETE CASCADE;


--
-- Name: error error_component_fk; Type: FK CONSTRAINT; Schema: uni_error; Owner: -
--

ALTER TABLE ONLY uni_error.error
    ADD CONSTRAINT error_component_fk FOREIGN KEY (id_component) REFERENCES uni_component.component(id) ON DELETE CASCADE;


--
-- Name: SCHEMA cmn_doc; Type: ACL; Schema: -; Owner: -
--

GRANT USAGE ON SCHEMA cmn_doc TO uni_user;
GRANT ALL ON SCHEMA cmn_doc TO uni_admin;


--
-- Name: SCHEMA uni_api; Type: ACL; Schema: -; Owner: -
--

GRANT ALL ON SCHEMA uni_api TO uni_admin;
GRANT USAGE ON SCHEMA uni_api TO uni_user;


--
-- Name: SCHEMA uni_component; Type: ACL; Schema: -; Owner: -
--

GRANT ALL ON SCHEMA uni_component TO uni_admin;
GRANT USAGE ON SCHEMA uni_component TO uni_user;


--
-- Name: SCHEMA uni_const; Type: ACL; Schema: -; Owner: -
--

GRANT ALL ON SCHEMA uni_const TO uni_admin;
GRANT USAGE ON SCHEMA uni_const TO uni_user;


--
-- Name: SCHEMA uni_error; Type: ACL; Schema: -; Owner: -
--

GRANT ALL ON SCHEMA uni_error TO uni_admin;
GRANT USAGE ON SCHEMA uni_error TO uni_user;


--
-- Name: SCHEMA uni_generator; Type: ACL; Schema: -; Owner: -
--

GRANT ALL ON SCHEMA uni_generator TO uni_admin;
GRANT USAGE ON SCHEMA uni_generator TO uni_user;


--
-- Name: FUNCTION doc__after_edit(idp_self public.t_id); Type: ACL; Schema: cmn_doc; Owner: -
--

GRANT ALL ON FUNCTION cmn_doc.doc__after_edit(idp_self public.t_id) TO uni_user;


--
-- Name: FUNCTION doc__delete_record(idp_self public.t_id); Type: ACL; Schema: cmn_doc; Owner: -
--

GRANT ALL ON FUNCTION cmn_doc.doc__delete_record(idp_self public.t_id) TO uni_user;


--
-- Name: TABLE doc; Type: ACL; Schema: cmn_doc; Owner: -
--

GRANT ALL ON TABLE cmn_doc.doc TO uni_admin;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE cmn_doc.doc TO uni_user;


--
-- Name: FUNCTION doc__get_row(idp_self public.t_id); Type: ACL; Schema: cmn_doc; Owner: -
--

GRANT ALL ON FUNCTION cmn_doc.doc__get_row(idp_self public.t_id) TO uni_user;


--
-- Name: FUNCTION doc__insert_record(); Type: ACL; Schema: cmn_doc; Owner: -
--

GRANT ALL ON FUNCTION cmn_doc.doc__insert_record() TO uni_user;


--
-- Name: FUNCTION doc__lock_record(idp_self public.t_id); Type: ACL; Schema: cmn_doc; Owner: -
--

GRANT ALL ON FUNCTION cmn_doc.doc__lock_record(idp_self public.t_id) TO uni_user;


--
-- Name: FUNCTION doc__set_date(idp_self public.t_id, p_value public.t_date, bp_internal_call public.t_boolean); Type: ACL; Schema: cmn_doc; Owner: -
--

GRANT ALL ON FUNCTION cmn_doc.doc__set_date(idp_self public.t_id, p_value public.t_date, bp_internal_call public.t_boolean) TO uni_user;


--
-- Name: FUNCTION doc__set_description(idp_self public.t_id, p_value public.t_description, bp_internal_call public.t_boolean); Type: ACL; Schema: cmn_doc; Owner: -
--

GRANT ALL ON FUNCTION cmn_doc.doc__set_description(idp_self public.t_id, p_value public.t_description, bp_internal_call public.t_boolean) TO uni_user;


--
-- Name: FUNCTION doc__set_number(idp_self public.t_id, p_value public.t_shortstring, bp_internal_call public.t_boolean); Type: ACL; Schema: cmn_doc; Owner: -
--

GRANT ALL ON FUNCTION cmn_doc.doc__set_number(idp_self public.t_id, p_value public.t_shortstring, bp_internal_call public.t_boolean) TO uni_user;


--
-- Name: FUNCTION doc__set_sum(idp_self public.t_id, p_value public.t_money, bp_internal_call public.t_boolean); Type: ACL; Schema: cmn_doc; Owner: -
--

GRANT ALL ON FUNCTION cmn_doc.doc__set_sum(idp_self public.t_id, p_value public.t_money, bp_internal_call public.t_boolean) TO uni_user;


--
-- Name: FUNCTION doc__validate(idp_self public.t_id); Type: ACL; Schema: cmn_doc; Owner: -
--

GRANT ALL ON FUNCTION cmn_doc.doc__validate(idp_self public.t_id) TO uni_user;


--
-- Name: FUNCTION doc_item__after_edit(idp_self public.t_id); Type: ACL; Schema: cmn_doc; Owner: -
--

GRANT ALL ON FUNCTION cmn_doc.doc_item__after_edit(idp_self public.t_id) TO uni_user;


--
-- Name: FUNCTION doc_item__delete_record(idp_self public.t_id); Type: ACL; Schema: cmn_doc; Owner: -
--

GRANT ALL ON FUNCTION cmn_doc.doc_item__delete_record(idp_self public.t_id) TO uni_user;


--
-- Name: TABLE doc_item; Type: ACL; Schema: cmn_doc; Owner: -
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE cmn_doc.doc_item TO uni_user;
GRANT ALL ON TABLE cmn_doc.doc_item TO uni_admin;


--
-- Name: FUNCTION doc_item__get_row(idp_self public.t_id); Type: ACL; Schema: cmn_doc; Owner: -
--

GRANT ALL ON FUNCTION cmn_doc.doc_item__get_row(idp_self public.t_id) TO uni_user;


--
-- Name: FUNCTION doc_item__insert_record(idp_doc public.t_id); Type: ACL; Schema: cmn_doc; Owner: -
--

GRANT ALL ON FUNCTION cmn_doc.doc_item__insert_record(idp_doc public.t_id) TO uni_user;


--
-- Name: FUNCTION doc_item__lock_record(idp_self public.t_id); Type: ACL; Schema: cmn_doc; Owner: -
--

GRANT ALL ON FUNCTION cmn_doc.doc_item__lock_record(idp_self public.t_id) TO uni_user;


--
-- Name: FUNCTION doc_item__set_caption(idp_self public.t_id, p_value public.t_caption, bp_internal_call public.t_boolean); Type: ACL; Schema: cmn_doc; Owner: -
--

GRANT ALL ON FUNCTION cmn_doc.doc_item__set_caption(idp_self public.t_id, p_value public.t_caption, bp_internal_call public.t_boolean) TO uni_user;


--
-- Name: FUNCTION doc_item__set_doc(idp_self public.t_id, p_value public.t_id, bp_internal_call public.t_boolean); Type: ACL; Schema: cmn_doc; Owner: -
--

GRANT ALL ON FUNCTION cmn_doc.doc_item__set_doc(idp_self public.t_id, p_value public.t_id, bp_internal_call public.t_boolean) TO uni_user;


--
-- Name: FUNCTION doc_item__set_number(idp_self public.t_id, p_value public.t_shortstring, bp_internal_call public.t_boolean); Type: ACL; Schema: cmn_doc; Owner: -
--

GRANT ALL ON FUNCTION cmn_doc.doc_item__set_number(idp_self public.t_id, p_value public.t_shortstring, bp_internal_call public.t_boolean) TO uni_user;


--
-- Name: FUNCTION doc_item__set_order(idp_self public.t_id, p_value public.t_integer, bp_internal_call public.t_boolean); Type: ACL; Schema: cmn_doc; Owner: -
--

GRANT ALL ON FUNCTION cmn_doc.doc_item__set_order(idp_self public.t_id, p_value public.t_integer, bp_internal_call public.t_boolean) TO uni_user;


--
-- Name: FUNCTION doc_item__set_sum(idp_self public.t_id, p_value public.t_money, bp_internal_call public.t_boolean); Type: ACL; Schema: cmn_doc; Owner: -
--

GRANT ALL ON FUNCTION cmn_doc.doc_item__set_sum(idp_self public.t_id, p_value public.t_money, bp_internal_call public.t_boolean) TO uni_user;


--
-- Name: FUNCTION doc_item__validate(idp_self public.t_id); Type: ACL; Schema: cmn_doc; Owner: -
--

GRANT ALL ON FUNCTION cmn_doc.doc_item__validate(idp_self public.t_id) TO uni_user;


--
-- Name: FUNCTION get_table_id(sp_schema public.t_name, sp_table public.t_name); Type: ACL; Schema: uni_api; Owner: -
--

GRANT ALL ON FUNCTION uni_api.get_table_id(sp_schema public.t_name, sp_table public.t_name) TO uni_user;
GRANT ALL ON FUNCTION uni_api.get_table_id(sp_schema public.t_name, sp_table public.t_name) TO uni_admin;


--
-- Name: FUNCTION set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_boolean, sp_identityfield public.t_name); Type: ACL; Schema: uni_api; Owner: -
--

GRANT ALL ON FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_boolean, sp_identityfield public.t_name) TO uni_user;
GRANT ALL ON FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_boolean, sp_identityfield public.t_name) TO uni_admin;


--
-- Name: FUNCTION set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_caption, sp_identityfield public.t_name); Type: ACL; Schema: uni_api; Owner: -
--

GRANT ALL ON FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_caption, sp_identityfield public.t_name) TO uni_user;
GRANT ALL ON FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_caption, sp_identityfield public.t_name) TO uni_admin;


--
-- Name: FUNCTION set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_clob, sp_identityfield public.t_name); Type: ACL; Schema: uni_api; Owner: -
--

GRANT ALL ON FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_clob, sp_identityfield public.t_name) TO uni_user;
GRANT ALL ON FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_clob, sp_identityfield public.t_name) TO uni_admin;


--
-- Name: FUNCTION set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_code, sp_identityfield public.t_name); Type: ACL; Schema: uni_api; Owner: -
--

GRANT ALL ON FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_code, sp_identityfield public.t_name) TO uni_user;
GRANT ALL ON FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_code, sp_identityfield public.t_name) TO uni_admin;


--
-- Name: FUNCTION set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_date, sp_identityfield public.t_name); Type: ACL; Schema: uni_api; Owner: -
--

GRANT ALL ON FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_date, sp_identityfield public.t_name) TO uni_user;
GRANT ALL ON FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_date, sp_identityfield public.t_name) TO uni_admin;


--
-- Name: FUNCTION set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_float, sp_identityfield public.t_name); Type: ACL; Schema: uni_api; Owner: -
--

GRANT ALL ON FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_float, sp_identityfield public.t_name) TO uni_user;
GRANT ALL ON FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_float, sp_identityfield public.t_name) TO uni_admin;


--
-- Name: FUNCTION set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_html, sp_identityfield public.t_name); Type: ACL; Schema: uni_api; Owner: -
--

GRANT ALL ON FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_html, sp_identityfield public.t_name) TO uni_user;
GRANT ALL ON FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_html, sp_identityfield public.t_name) TO uni_admin;


--
-- Name: FUNCTION set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_id, sp_identityfield public.t_name); Type: ACL; Schema: uni_api; Owner: -
--

GRANT ALL ON FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_id, sp_identityfield public.t_name) TO uni_user;
GRANT ALL ON FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_id, sp_identityfield public.t_name) TO uni_admin;


--
-- Name: FUNCTION set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_integer, sp_identityfield public.t_name); Type: ACL; Schema: uni_api; Owner: -
--

GRANT ALL ON FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_integer, sp_identityfield public.t_name) TO uni_user;
GRANT ALL ON FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_integer, sp_identityfield public.t_name) TO uni_admin;


--
-- Name: FUNCTION set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_json, sp_identityfield public.t_name); Type: ACL; Schema: uni_api; Owner: -
--

GRANT ALL ON FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_json, sp_identityfield public.t_name) TO uni_user;
GRANT ALL ON FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_json, sp_identityfield public.t_name) TO uni_admin;


--
-- Name: FUNCTION set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_longstring, sp_identityfield public.t_name); Type: ACL; Schema: uni_api; Owner: -
--

GRANT ALL ON FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_longstring, sp_identityfield public.t_name) TO uni_user;
GRANT ALL ON FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_longstring, sp_identityfield public.t_name) TO uni_admin;


--
-- Name: FUNCTION set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_money, sp_identityfield public.t_name); Type: ACL; Schema: uni_api; Owner: -
--

GRANT ALL ON FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_money, sp_identityfield public.t_name) TO uni_user;
GRANT ALL ON FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_money, sp_identityfield public.t_name) TO uni_admin;


--
-- Name: FUNCTION set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_name, sp_identityfield public.t_name); Type: ACL; Schema: uni_api; Owner: -
--

GRANT ALL ON FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_name, sp_identityfield public.t_name) TO uni_user;
GRANT ALL ON FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_name, sp_identityfield public.t_name) TO uni_admin;


--
-- Name: FUNCTION set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_shortstring, sp_identityfield public.t_name); Type: ACL; Schema: uni_api; Owner: -
--

GRANT ALL ON FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_shortstring, sp_identityfield public.t_name) TO uni_user;
GRANT ALL ON FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_shortstring, sp_identityfield public.t_name) TO uni_admin;


--
-- Name: FUNCTION set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_xml, sp_identityfield public.t_name); Type: ACL; Schema: uni_api; Owner: -
--

GRANT ALL ON FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_xml, sp_identityfield public.t_name) TO uni_user;
GRANT ALL ON FUNCTION uni_api.set_table_field_value(sp_schema public.t_name, sp_table public.t_name, sp_field public.t_name, idp_self public.t_id, p_value public.t_xml, sp_identityfield public.t_name) TO uni_admin;


--
-- Name: FUNCTION component__after_edit(idp_self public.t_id); Type: ACL; Schema: uni_component; Owner: -
--

GRANT ALL ON FUNCTION uni_component.component__after_edit(idp_self public.t_id) TO uni_user;
GRANT ALL ON FUNCTION uni_component.component__after_edit(idp_self public.t_id) TO uni_admin;


--
-- Name: FUNCTION component__delete_record(idp_self public.t_id); Type: ACL; Schema: uni_component; Owner: -
--

GRANT ALL ON FUNCTION uni_component.component__delete_record(idp_self public.t_id) TO uni_user;
GRANT ALL ON FUNCTION uni_component.component__delete_record(idp_self public.t_id) TO uni_admin;


--
-- Name: FUNCTION component__find_by_name(sp_name public.t_name); Type: ACL; Schema: uni_component; Owner: -
--

GRANT ALL ON FUNCTION uni_component.component__find_by_name(sp_name public.t_name) TO uni_user;
GRANT ALL ON FUNCTION uni_component.component__find_by_name(sp_name public.t_name) TO uni_admin;


--
-- Name: TABLE component; Type: ACL; Schema: uni_component; Owner: -
--

GRANT SELECT ON TABLE uni_component.component TO uni_user;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE uni_component.component TO uni_admin;


--
-- Name: FUNCTION component__get_row(idp_self public.t_id); Type: ACL; Schema: uni_component; Owner: -
--

GRANT ALL ON FUNCTION uni_component.component__get_row(idp_self public.t_id) TO uni_user;
GRANT ALL ON FUNCTION uni_component.component__get_row(idp_self public.t_id) TO uni_admin;


--
-- Name: FUNCTION component__insert_record(sp_name public.t_name); Type: ACL; Schema: uni_component; Owner: -
--

GRANT ALL ON FUNCTION uni_component.component__insert_record(sp_name public.t_name) TO uni_user;
GRANT ALL ON FUNCTION uni_component.component__insert_record(sp_name public.t_name) TO uni_admin;


--
-- Name: FUNCTION component__lock_record(idp_self public.t_id); Type: ACL; Schema: uni_component; Owner: -
--

GRANT ALL ON FUNCTION uni_component.component__lock_record(idp_self public.t_id) TO uni_user;
GRANT ALL ON FUNCTION uni_component.component__lock_record(idp_self public.t_id) TO uni_admin;


--
-- Name: FUNCTION component__set_caption(idp_self public.t_id, p_value public.t_caption); Type: ACL; Schema: uni_component; Owner: -
--

GRANT ALL ON FUNCTION uni_component.component__set_caption(idp_self public.t_id, p_value public.t_caption) TO uni_user;
GRANT ALL ON FUNCTION uni_component.component__set_caption(idp_self public.t_id, p_value public.t_caption) TO uni_admin;


--
-- Name: FUNCTION component__set_description(idp_self public.t_id, p_value public.t_description); Type: ACL; Schema: uni_component; Owner: -
--

GRANT ALL ON FUNCTION uni_component.component__set_description(idp_self public.t_id, p_value public.t_description) TO uni_user;
GRANT ALL ON FUNCTION uni_component.component__set_description(idp_self public.t_id, p_value public.t_description) TO uni_admin;


--
-- Name: FUNCTION component__set_name(idp_self public.t_id, p_value public.t_name); Type: ACL; Schema: uni_component; Owner: -
--

GRANT ALL ON FUNCTION uni_component.component__set_name(idp_self public.t_id, p_value public.t_name) TO uni_user;
GRANT ALL ON FUNCTION uni_component.component__set_name(idp_self public.t_id, p_value public.t_name) TO uni_admin;


--
-- Name: FUNCTION component__set_parent(idp_self public.t_id, p_value public.t_id); Type: ACL; Schema: uni_component; Owner: -
--

GRANT ALL ON FUNCTION uni_component.component__set_parent(idp_self public.t_id, p_value public.t_id) TO uni_user;
GRANT ALL ON FUNCTION uni_component.component__set_parent(idp_self public.t_id, p_value public.t_id) TO uni_admin;


--
-- Name: FUNCTION component__validate(idp_self public.t_id); Type: ACL; Schema: uni_component; Owner: -
--

GRANT ALL ON FUNCTION uni_component.component__validate(idp_self public.t_id) TO uni_user;
GRANT ALL ON FUNCTION uni_component.component__validate(idp_self public.t_id) TO uni_admin;


--
-- Name: FUNCTION endl(); Type: ACL; Schema: uni_const; Owner: -
--

GRANT ALL ON FUNCTION uni_const.endl() TO uni_user;
GRANT ALL ON FUNCTION uni_const.endl() TO uni_admin;


--
-- Name: FUNCTION max_date(); Type: ACL; Schema: uni_const; Owner: -
--

GRANT ALL ON FUNCTION uni_const.max_date() TO uni_user;


--
-- Name: FUNCTION min_date(); Type: ACL; Schema: uni_const; Owner: -
--

GRANT ALL ON FUNCTION uni_const.min_date() TO uni_user;


--
-- Name: FUNCTION reg_col_type(); Type: ACL; Schema: uni_const; Owner: -
--

GRANT ALL ON FUNCTION uni_const.reg_col_type() TO uni_admin;
GRANT ALL ON FUNCTION uni_const.reg_col_type() TO uni_user;


--
-- Name: FUNCTION reg_replace(sp_prefix public.t_name); Type: ACL; Schema: uni_const; Owner: -
--

GRANT ALL ON FUNCTION uni_const.reg_replace(sp_prefix public.t_name) TO uni_admin;
GRANT ALL ON FUNCTION uni_const.reg_replace(sp_prefix public.t_name) TO uni_user;


--
-- Name: FUNCTION error__after_edit(idp_self public.t_id); Type: ACL; Schema: uni_error; Owner: -
--

GRANT ALL ON FUNCTION uni_error.error__after_edit(idp_self public.t_id) TO uni_user;
GRANT ALL ON FUNCTION uni_error.error__after_edit(idp_self public.t_id) TO uni_admin;


--
-- Name: FUNCTION error__delete_record(idp_self public.t_id); Type: ACL; Schema: uni_error; Owner: -
--

GRANT ALL ON FUNCTION uni_error.error__delete_record(idp_self public.t_id) TO uni_user;
GRANT ALL ON FUNCTION uni_error.error__delete_record(idp_self public.t_id) TO uni_admin;


--
-- Name: FUNCTION error__find_by_name(sp_name public.t_name); Type: ACL; Schema: uni_error; Owner: -
--

GRANT ALL ON FUNCTION uni_error.error__find_by_name(sp_name public.t_name) TO uni_user;
GRANT ALL ON FUNCTION uni_error.error__find_by_name(sp_name public.t_name) TO uni_admin;


--
-- Name: TABLE error; Type: ACL; Schema: uni_error; Owner: -
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE uni_error.error TO uni_admin;
GRANT SELECT ON TABLE uni_error.error TO uni_user;


--
-- Name: FUNCTION error__get_row(idp_self public.t_id); Type: ACL; Schema: uni_error; Owner: -
--

GRANT ALL ON FUNCTION uni_error.error__get_row(idp_self public.t_id) TO uni_user;
GRANT ALL ON FUNCTION uni_error.error__get_row(idp_self public.t_id) TO uni_admin;


--
-- Name: FUNCTION error__insert_record(sp_name public.t_name, idp_component public.t_id); Type: ACL; Schema: uni_error; Owner: -
--

GRANT ALL ON FUNCTION uni_error.error__insert_record(sp_name public.t_name, idp_component public.t_id) TO uni_user;
GRANT ALL ON FUNCTION uni_error.error__insert_record(sp_name public.t_name, idp_component public.t_id) TO uni_admin;


--
-- Name: FUNCTION error__lock_record(idp_self public.t_id); Type: ACL; Schema: uni_error; Owner: -
--

GRANT ALL ON FUNCTION uni_error.error__lock_record(idp_self public.t_id) TO uni_user;
GRANT ALL ON FUNCTION uni_error.error__lock_record(idp_self public.t_id) TO uni_admin;


--
-- Name: FUNCTION error__set_caption(idp_self public.t_id, p_value public.t_caption); Type: ACL; Schema: uni_error; Owner: -
--

GRANT ALL ON FUNCTION uni_error.error__set_caption(idp_self public.t_id, p_value public.t_caption) TO uni_user;
GRANT ALL ON FUNCTION uni_error.error__set_caption(idp_self public.t_id, p_value public.t_caption) TO uni_admin;


--
-- Name: FUNCTION error__set_component(idp_self public.t_id, p_value public.t_id); Type: ACL; Schema: uni_error; Owner: -
--

GRANT ALL ON FUNCTION uni_error.error__set_component(idp_self public.t_id, p_value public.t_id) TO uni_user;
GRANT ALL ON FUNCTION uni_error.error__set_component(idp_self public.t_id, p_value public.t_id) TO uni_admin;


--
-- Name: FUNCTION error__set_created(idp_self public.t_id, p_value public.t_datetime); Type: ACL; Schema: uni_error; Owner: -
--

GRANT ALL ON FUNCTION uni_error.error__set_created(idp_self public.t_id, p_value public.t_datetime) TO uni_user;
GRANT ALL ON FUNCTION uni_error.error__set_created(idp_self public.t_id, p_value public.t_datetime) TO uni_admin;


--
-- Name: FUNCTION error__set_description(idp_self public.t_id, p_value public.t_description); Type: ACL; Schema: uni_error; Owner: -
--

GRANT ALL ON FUNCTION uni_error.error__set_description(idp_self public.t_id, p_value public.t_description) TO uni_user;
GRANT ALL ON FUNCTION uni_error.error__set_description(idp_self public.t_id, p_value public.t_description) TO uni_admin;


--
-- Name: FUNCTION error__set_edited(idp_self public.t_id, p_value public.t_datetime); Type: ACL; Schema: uni_error; Owner: -
--

GRANT ALL ON FUNCTION uni_error.error__set_edited(idp_self public.t_id, p_value public.t_datetime) TO uni_user;
GRANT ALL ON FUNCTION uni_error.error__set_edited(idp_self public.t_id, p_value public.t_datetime) TO uni_admin;


--
-- Name: FUNCTION error__set_name(idp_self public.t_id, p_value public.t_name); Type: ACL; Schema: uni_error; Owner: -
--

GRANT ALL ON FUNCTION uni_error.error__set_name(idp_self public.t_id, p_value public.t_name) TO uni_user;
GRANT ALL ON FUNCTION uni_error.error__set_name(idp_self public.t_id, p_value public.t_name) TO uni_admin;


--
-- Name: FUNCTION error__validate(idp_self public.t_id); Type: ACL; Schema: uni_error; Owner: -
--

GRANT ALL ON FUNCTION uni_error.error__validate(idp_self public.t_id) TO uni_user;
GRANT ALL ON FUNCTION uni_error.error__validate(idp_self public.t_id) TO uni_admin;


--
-- Name: FUNCTION generate(sp_component public.t_name, sp_name public.t_name, VARIADIC params public.t_shortstring[]); Type: ACL; Schema: uni_error; Owner: -
--

GRANT ALL ON FUNCTION uni_error.generate(sp_component public.t_name, sp_name public.t_name, VARIADIC params public.t_shortstring[]) TO uni_user;
GRANT ALL ON FUNCTION uni_error.generate(sp_component public.t_name, sp_name public.t_name, VARIADIC params public.t_shortstring[]) TO uni_admin;


--
-- Name: FUNCTION generate_after_edit(sp_schemaname public.t_name, sp_tablename public.t_name); Type: ACL; Schema: uni_generator; Owner: -
--

GRANT ALL ON FUNCTION uni_generator.generate_after_edit(sp_schemaname public.t_name, sp_tablename public.t_name) TO uni_user;
GRANT ALL ON FUNCTION uni_generator.generate_after_edit(sp_schemaname public.t_name, sp_tablename public.t_name) TO uni_admin;


--
-- Name: FUNCTION generate_delete_record(sp_schemaname public.t_name, sp_tablename public.t_name); Type: ACL; Schema: uni_generator; Owner: -
--

GRANT ALL ON FUNCTION uni_generator.generate_delete_record(sp_schemaname public.t_name, sp_tablename public.t_name) TO uni_user;
GRANT ALL ON FUNCTION uni_generator.generate_delete_record(sp_schemaname public.t_name, sp_tablename public.t_name) TO uni_admin;


--
-- Name: FUNCTION generate_find_by_code(sp_schemaname public.t_name, sp_tablename public.t_name); Type: ACL; Schema: uni_generator; Owner: -
--

GRANT ALL ON FUNCTION uni_generator.generate_find_by_code(sp_schemaname public.t_name, sp_tablename public.t_name) TO uni_user;
GRANT ALL ON FUNCTION uni_generator.generate_find_by_code(sp_schemaname public.t_name, sp_tablename public.t_name) TO uni_admin;


--
-- Name: FUNCTION generate_find_by_name(sp_schemaname public.t_name, sp_tablename public.t_name); Type: ACL; Schema: uni_generator; Owner: -
--

GRANT ALL ON FUNCTION uni_generator.generate_find_by_name(sp_schemaname public.t_name, sp_tablename public.t_name) TO uni_admin;
GRANT ALL ON FUNCTION uni_generator.generate_find_by_name(sp_schemaname public.t_name, sp_tablename public.t_name) TO uni_user;


--
-- Name: FUNCTION generate_get_row(sp_schemaname public.t_name, sp_tablename public.t_name); Type: ACL; Schema: uni_generator; Owner: -
--

GRANT ALL ON FUNCTION uni_generator.generate_get_row(sp_schemaname public.t_name, sp_tablename public.t_name) TO uni_user;
GRANT ALL ON FUNCTION uni_generator.generate_get_row(sp_schemaname public.t_name, sp_tablename public.t_name) TO uni_admin;


--
-- Name: FUNCTION generate_grants(sp_schemaname public.t_name, sp_tablename public.t_name, sap_roles public.t_shortstringarray); Type: ACL; Schema: uni_generator; Owner: -
--

GRANT ALL ON FUNCTION uni_generator.generate_grants(sp_schemaname public.t_name, sp_tablename public.t_name, sap_roles public.t_shortstringarray) TO uni_user;
GRANT ALL ON FUNCTION uni_generator.generate_grants(sp_schemaname public.t_name, sp_tablename public.t_name, sap_roles public.t_shortstringarray) TO uni_admin;


--
-- Name: FUNCTION generate_insert_record(sp_schemaname public.t_name, sp_tablename public.t_name); Type: ACL; Schema: uni_generator; Owner: -
--

GRANT ALL ON FUNCTION uni_generator.generate_insert_record(sp_schemaname public.t_name, sp_tablename public.t_name) TO uni_user;
GRANT ALL ON FUNCTION uni_generator.generate_insert_record(sp_schemaname public.t_name, sp_tablename public.t_name) TO uni_admin;


--
-- Name: FUNCTION generate_lock_record(sp_schemaname public.t_name, sp_tablename public.t_name); Type: ACL; Schema: uni_generator; Owner: -
--

GRANT ALL ON FUNCTION uni_generator.generate_lock_record(sp_schemaname public.t_name, sp_tablename public.t_name) TO uni_user;
GRANT ALL ON FUNCTION uni_generator.generate_lock_record(sp_schemaname public.t_name, sp_tablename public.t_name) TO uni_admin;


--
-- Name: FUNCTION generate_setters(sp_schemaname public.t_name, sp_tablename public.t_name); Type: ACL; Schema: uni_generator; Owner: -
--

GRANT ALL ON FUNCTION uni_generator.generate_setters(sp_schemaname public.t_name, sp_tablename public.t_name) TO uni_user;
GRANT ALL ON FUNCTION uni_generator.generate_setters(sp_schemaname public.t_name, sp_tablename public.t_name) TO uni_admin;


--
-- Name: FUNCTION generate_table_api(sp_schemaname public.t_name, sp_tablename public.t_name); Type: ACL; Schema: uni_generator; Owner: -
--

GRANT ALL ON FUNCTION uni_generator.generate_table_api(sp_schemaname public.t_name, sp_tablename public.t_name) TO uni_user;
GRANT ALL ON FUNCTION uni_generator.generate_table_api(sp_schemaname public.t_name, sp_tablename public.t_name) TO uni_admin;


--
-- Name: FUNCTION generate_validate(sp_schemaname public.t_name, sp_tablename public.t_name); Type: ACL; Schema: uni_generator; Owner: -
--

GRANT ALL ON FUNCTION uni_generator.generate_validate(sp_schemaname public.t_name, sp_tablename public.t_name) TO uni_user;
GRANT ALL ON FUNCTION uni_generator.generate_validate(sp_schemaname public.t_name, sp_tablename public.t_name) TO uni_admin;


--
-- Name: SEQUENCE seq_doc; Type: ACL; Schema: cmn_doc; Owner: -
--

GRANT ALL ON SEQUENCE cmn_doc.seq_doc TO uni_admin;
GRANT ALL ON SEQUENCE cmn_doc.seq_doc TO uni_user;


--
-- Name: SEQUENCE seq_doc_item; Type: ACL; Schema: cmn_doc; Owner: -
--

GRANT ALL ON SEQUENCE cmn_doc.seq_doc_item TO uni_admin;
GRANT ALL ON SEQUENCE cmn_doc.seq_doc_item TO uni_user;


--
-- Name: SEQUENCE seq_component; Type: ACL; Schema: uni_component; Owner: -
--

GRANT SELECT ON SEQUENCE uni_component.seq_component TO uni_user;


--
-- Name: TABLE component_errors; Type: ACL; Schema: uni_error; Owner: -
--

GRANT SELECT ON TABLE uni_error.component_errors TO uni_admin;
GRANT SELECT ON TABLE uni_error.component_errors TO uni_user;


--
-- PostgreSQL database dump complete
--

